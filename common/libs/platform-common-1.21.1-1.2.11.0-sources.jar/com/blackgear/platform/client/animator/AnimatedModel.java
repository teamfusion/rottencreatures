package com.blackgear.platform.client.animator;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_630;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public interface AnimatedModel {
    class_630 root();

    default Optional<class_630> getAnyDescendantWithName(String name) {
        return root().method_32088()
            .filter(part -> part.method_41919(name))
            .findFirst()
            .map(part -> part.method_32086(name));
    }
}