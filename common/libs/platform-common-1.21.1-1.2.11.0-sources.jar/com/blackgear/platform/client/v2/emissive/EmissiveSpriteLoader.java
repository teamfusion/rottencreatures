package com.blackgear.platform.client.v2.emissive;

import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_2960;

public interface EmissiveSpriteLoader {
    ThreadLocal<EmissiveSpriteLoader> THREAD_LOCAL = new ThreadLocal<>();

    @Nullable
    EmissiveSpriteLoader.Controller getController(class_2960 atlas);

    interface Controller {
        @Nullable
        Map<class_2960, class_2960> getEmissiveMappings();

        void setEmissiveMappings(Map<class_2960, class_2960> mappings);

        void markHasEmissives();
    }
}