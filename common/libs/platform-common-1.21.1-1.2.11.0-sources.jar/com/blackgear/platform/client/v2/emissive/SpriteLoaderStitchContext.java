package com.blackgear.platform.client.v2.emissive;

import java.util.Map;
import net.minecraft.class_2960;

public interface SpriteLoaderStitchContext {
    ThreadLocal<SpriteLoaderStitchContext> THREAD_LOCAL = new ThreadLocal<>();

    Map<class_2960, class_2960> getEmissiveMappings();

    void markHasEmissives();
}