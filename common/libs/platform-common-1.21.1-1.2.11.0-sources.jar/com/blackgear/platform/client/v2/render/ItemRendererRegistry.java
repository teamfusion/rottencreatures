package com.blackgear.platform.client.v2.render;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

public class ItemRendererRegistry {
    @ExpectPlatform
    public static void registerRenderer(class_1935 item, DynamicItemRenderer renderer) {
        throw new AssertionError();
    }

    public interface DynamicItemRenderer {
        void render(class_1799 stack, class_811 context, class_4587 pose, class_4597 buffer, int packedLight, int combinedOverlay);
    }
}