package com.blackgear.platform.client.v2.emissive;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1058;

public class Emissiveness {
    public static final Emissiveness INSTANCE = new Emissiveness();
    private static final Map<class_1058, class_1058> CACHE = new ConcurrentHashMap<>();

    public class_1058 getEmissiveSprite(class_1058 sprite) {
        return CACHE.computeIfAbsent(sprite, this::lookupEmissiveSprite);
    }

    private class_1058 lookupEmissiveSprite(class_1058 sprite) {
        return ((EmissiveSpriteHolder) sprite).getEmissiveSprite();
    }

    public void clearCache() {
        CACHE.clear();
    }
}