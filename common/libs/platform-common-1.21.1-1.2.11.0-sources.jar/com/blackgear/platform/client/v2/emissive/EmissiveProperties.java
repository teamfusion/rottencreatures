package com.blackgear.platform.client.v2.emissive;

import com.blackgear.platform.Platform;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import net.minecraft.class_2960;
import net.minecraft.class_3300;

public class EmissiveProperties {
    public static final class_2960 PROPERTIES = class_2960.method_60656("optifine/emissive.properties");
    private static String suffix;

    @Nullable
    public static String getSuffix() {
        return suffix;
    }

    public static void load(class_3300 manager) {
        suffix = null;
        manager.method_14486(PROPERTIES).ifPresent(resource -> {
            try (InputStream stream = resource.method_14482()) {
                Properties properties = new Properties();
                properties.load(stream);
                suffix = properties.getProperty("suffix.emissive");
            } catch (IOException exception) {
                Platform.LOGGER.error("Failed to load emissive suffix from file '{}'", PROPERTIES, exception);
            }
        });
    }
}