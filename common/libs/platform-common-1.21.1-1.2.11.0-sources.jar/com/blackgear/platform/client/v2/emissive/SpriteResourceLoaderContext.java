package com.blackgear.platform.client.v2.emissive;

import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_2960;

public interface SpriteResourceLoaderContext {
    ThreadLocal<SpriteResourceLoaderContext> THREAD_LOCAL = new ThreadLocal<>();

    void setEmissiveMappings(@Nullable Map<class_2960, class_2960> mappings);
}