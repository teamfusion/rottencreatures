package com.blackgear.platform.client.v2.emissive;

import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_1059;
import net.minecraft.class_1088;
import net.minecraft.class_2960;
import net.minecraft.class_3300;

public class EmissiveModelReloader {
    private final AtomicBoolean shouldWrap = new AtomicBoolean();
    private final EmissiveSpriteLoaderImpl spriteLoader;

    public EmissiveModelReloader(class_3300 manager) {
        this.spriteLoader = new EmissiveSpriteLoaderImpl(this.shouldWrap);
        EmissiveProperties.load(manager);
    }

    public void setContext() {
        EmissiveSpriteLoader.THREAD_LOCAL.set(this.spriteLoader);
    }

    public void clearContext() {
        Emissiveness.INSTANCE.clearCache();
        EmissiveSpriteLoader.THREAD_LOCAL.remove();
    }

    public void beforeBaking(class_1088 bakery) {
        EmissiveModelWrapper wrapper = EmissiveModelWrapper.create(this.shouldWrap.get());
        ((EmissiveModelWrapperHolder) bakery).setModelWrapper(wrapper);
    }

    private static class EmissiveSpriteLoaderImpl implements EmissiveSpriteLoader {
        private final Controller controller;

        private EmissiveSpriteLoaderImpl(AtomicBoolean markDirty) {
            this.controller = new ControllerImpl(markDirty);
        }

        @Override
        public @Nullable EmissiveSpriteLoader.Controller getController(class_2960 atlas) {
            return atlas.equals(class_1059.field_5275) ? this.controller : null;
        }

        private static class ControllerImpl implements Controller {
            @Nullable private volatile Map<class_2960, class_2960> mappings;
            private final AtomicBoolean markDirty;

            private ControllerImpl(AtomicBoolean markDirty) {
                this.markDirty = markDirty;
            }

            @Override
            public @Nullable Map<class_2960, class_2960> getEmissiveMappings() {
                return this.mappings;
            }

            @Override
            public void setEmissiveMappings(@Nullable Map<class_2960, class_2960> mappings) {
                this.mappings = mappings != null ? Map.copyOf(mappings) : null;
            }

            @Override
            public void markHasEmissives() {
                this.markDirty.set(true);
            }
        }
    }
}