package com.blackgear.platform.client.v2.emissive;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public class EmissiveModelWrapper {
    private final boolean shouldWrap;

    public EmissiveModelWrapper(boolean shouldWrap) {
        this.shouldWrap = shouldWrap;
    }

    public static EmissiveModelWrapper create(boolean shouldWrap) {
        return shouldWrap ? new EmissiveModelWrapper(true) : null;
    }

    public class_1087 wrap(@Nullable class_1087 model, class_2960 resource) {
        if (!this.shouldWrap || model == null) return model;

        if ((resource == null || !resource.equals(class_1088.field_5374)) && !model.method_4713()) {
            return getBakedModel(model);
        }

        return model;
    }

    @ExpectPlatform
    public static class_1087 getBakedModel(class_1087 model) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void bootstrap() {
        throw new AssertionError();
    }
}