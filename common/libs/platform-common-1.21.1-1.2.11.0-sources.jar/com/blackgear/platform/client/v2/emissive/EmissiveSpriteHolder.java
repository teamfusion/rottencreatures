package com.blackgear.platform.client.v2.emissive;

import net.minecraft.class_1058;
import org.jetbrains.annotations.Nullable;

public interface EmissiveSpriteHolder {
    @Nullable class_1058 getEmissiveSprite();

    void setEmissiveSprite(class_1058 sprite);
}