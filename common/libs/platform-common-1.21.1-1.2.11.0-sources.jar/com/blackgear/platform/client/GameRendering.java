package com.blackgear.platform.client;

import com.mojang.datafixers.util.Pair;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1091;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2484;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_322;
import net.minecraft.class_326;
import net.minecraft.class_3611;
import net.minecraft.class_4002;
import net.minecraft.class_5598;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_5614;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_707;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class GameRendering {
    public static final Map<class_1792, HandHeldModelEvent.Models> HAND_HELD_MODELS = new ConcurrentHashMap<>();
    public static final Map<class_2960, class_2960> MODEL_OVERRIDES = new ConcurrentHashMap<>();

    @ExpectPlatform
    public static void registerBlockColors(Consumer<BlockColorEvent> listener) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerItemColors(Consumer<ItemColorEvent> listener) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerBlockRenderers(Consumer<BlockRendererEvent> listener) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerEntityRenderers(Consumer<EntityRendererEvent> listener) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerBlockEntityRenderers(Consumer<BlockEntityRendererEvent> listener) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerModelLayers(Consumer<ModelLayerEvent> listener) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerSpecialModels(Consumer<SpecialModelEvent> listener) {
        throw new AssertionError();
    }

    public static void registerHandHeldModels(Consumer<HandHeldModelEvent> listener) {
        HandHeldModelEvent event = (item, original, handHeld) -> HAND_HELD_MODELS.put(item, new HandHeldModelEvent.Models(original, handHeld));
        listener.accept(event);
    }

    @ExpectPlatform
    public static void registerModelOverrides(Consumer<ModelOverrideEvent> listener) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerSkullRenderers(Consumer<SkullRendererEvent> listener) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerParticleFactories(Consumer<ParticleFactoryEvent> listener) {
        throw new AssertionError();
    }

    public interface BlockColorEvent {
        void register(class_322 color, class_2248... blocks);

        int getColor(class_2680 state, class_1920 level, class_2338 pos, int tint);
    }

    public interface ItemColorEvent {
        void register(class_326 color, class_1935... items);

        int getColor(class_1799 stack, int tint);
    }

    public interface BlockRendererEvent {
        void register(class_1921 type, class_2248... blocks);

        void register(class_1921 type, class_3611... fluids);
    }

    public interface EntityRendererEvent {
        <E extends class_1297> void register(class_1299<? extends E> type, class_5617<E> renderer);
    }

    public interface BlockEntityRendererEvent {
        <E extends class_2586> void register(class_2591<? extends E> type, class_5614<E> renderer);
    }

    public interface ModelLayerEvent {
        void register(class_5601 layer, Supplier<class_5607> definition);
    }

    public interface SpecialModelEvent {
        void register(class_2960 model);

        void register(class_2960... models);

        @Deprecated
        default void register(class_1091 model) {
            this.register(model.comp_2875());
        }

        @Deprecated
        default void register(class_1091... models) {
            for (class_1091 model : models) this.register(model.comp_2875());
        }
    }

    public interface ModelOverrideEvent {
        default void register(class_2960 original, class_2960 override, boolean condition) {
            if (condition) {
                MODEL_OVERRIDES.put(original, override);
            } else {
                MODEL_OVERRIDES.remove(original);
            }
        }

        default void register(class_2960 original, class_2960 override) {
            this.register(original, override, true);
        }
    }

    public interface HandHeldModelEvent {
        void register(class_1792 item, class_1091 original, class_1091 handheld);

        default void register(class_1792 item, class_2960 original, class_2960 handheld) {
            this.register(item, class_1091.method_61078(original), class_1091.method_61078(handheld));
        }

        record Models(class_1091 original, class_1091 handheld) {}
    }

    public interface SkullRendererEvent {
        void registerSkullModel(class_2484.class_2485 type, Function<class_630, class_5598> model, class_5601 layer);

        void registerSkullTexture(class_2484.class_2485 type, class_2960 texture);
    }

    public interface ParticleFactoryEvent {
        <T extends class_2394, P extends class_2396<T>> void register(Supplier<P> type, class_707<T> provider);

        <T extends class_2394, P extends class_2396<T>> void register(Supplier<P> type, Factory<T> factory);

        @FunctionalInterface
        interface Factory<T extends class_2394> {
            @NotNull class_707<T> create(class_4002 sprites);
        }
    }
}