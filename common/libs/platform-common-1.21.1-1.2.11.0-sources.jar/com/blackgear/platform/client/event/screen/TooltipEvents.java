package com.blackgear.platform.client.event.screen;

import com.blackgear.platform.core.util.event.Event;
import com.blackgear.platform.core.util.event.CancellableResult;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792.class_9635;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import java.util.List;

@Environment(EnvType.CLIENT)
public interface TooltipEvents {
    Event<Item> ITEM_SETUP = Event.create(Item.class);
    Event<RenderTooltip> RENDER_TOOLTIP = Event.cancellable(RenderTooltip.class);

    interface Item {
        void registerTooltip(class_1799 stack, class_9635 context, class_1836 flag, List<class_2561> components);
    }

    interface RenderTooltip {
        CancellableResult onRendering(class_332 graphics, List<? extends class_5684> texts, int x, int y);
    }
}