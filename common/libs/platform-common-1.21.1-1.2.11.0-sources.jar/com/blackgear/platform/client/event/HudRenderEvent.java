package com.blackgear.platform.client.event;

import com.blackgear.platform.core.util.event.Event;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1041;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_757;

@Environment(EnvType.CLIENT)
public class HudRenderEvent {
    public static final Event<RenderHud> RENDER_HUD = Event.create(RenderHud.class);
    
    @FunctionalInterface
    public interface RenderHud {
        void render(class_332 matrices, float tickDelta, ElementType type, RenderContext context);
    }

    public interface RenderContext {
        default class_1041 window() {
            return this.minecraft().method_22683();
        }

        default int screenWidth() {
            return this.window().method_4486();
        }

        default int screenHeight() {
            return this.window().method_4502();
        }

        default class_310 minecraft() {
            return class_310.method_1551();
        }

        default class_746 player() {
            return this.minecraft().field_1724;
        }

        default class_329 gui() {
            return this.minecraft().field_1705;
        }

        default void renderTextureOverlay(class_2960 texture, float alpha) {
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(class_757::method_34542);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
            RenderSystem.setShaderTexture(0, texture);
            class_289 tesselator = class_289.method_1348();
            class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1585);
            bufferBuilder.method_22912(0.0F, this.screenHeight(), -90.0F).method_22913(0.0F, 1.0F);
            bufferBuilder.method_22912(this.screenWidth(), this.screenHeight(), -90.0F).method_22913(.0F, 1.0F);
            bufferBuilder.method_22912(this.screenWidth(), 0.0F, -90.0F).method_22913(1.0F, 0.0F);
            bufferBuilder.method_22912(0.0F, 0.0F, -90.0F).method_22913(0.0F, 0.0F);
            class_286.method_43433(bufferBuilder.method_60800());
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        }
    }

    public enum ElementType {
        DEFAULT, HEALTH, EXPERIENCE, FIRST_PERSON, VIGNETTE
    }
}