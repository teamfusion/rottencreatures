package com.blackgear.platform.client.event;

import com.blackgear.platform.core.util.event.Event;
import com.blackgear.platform.core.util.event.CancellableResult;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_6854;
import net.minecraft.class_758;

@Environment(EnvType.CLIENT)
public interface FogRendering {
    Event<FogDensity> FOG_DENSITY = Event.create(FogDensity.class, densities -> (camera, density) -> {
        for (FogDensity callback : densities) {
            return callback.setDensity(camera, density);
        }

        return density;
    });
    Event<FogColor> FOG_COLOR = Event.create(FogColor.class);
    Event<FogRender> FOG_RENDER = Event.cancellable(FogRender.class);

    interface FogDensity {
        float setDensity(class_4184 camera, float density);
    }

    interface FogColor {
        void setColor(ColorData data, float partialTicks);
    }

    interface FogRender {
        CancellableResult onFogRender(class_758.class_4596 mode, class_5636 type, class_4184 camera, float partialTick, float renderDistance, float nearDistance, float farDistance, class_6854 shape, FogData fogData);
    }

    class FogData {
        private float farPlaneDistance;
        private float nearPlaneDistance;
        private class_6854 shape;

        public FogData(float nearPlaneDistance, float farPlaneDistance, class_6854 shape) {
            this.farPlaneDistance = farPlaneDistance;
            this.nearPlaneDistance = nearPlaneDistance;
            this.shape = shape;
        }

        public float getFarPlaneDistance() {
            return this.farPlaneDistance;
        }

        public float getNearPlaneDistance() {
            return this.nearPlaneDistance;
        }

        public class_6854 getShape() {
            return this.shape;
        }

        public void setFarPlaneDistance(float farPlaneDistance) {
            this.farPlaneDistance = farPlaneDistance;
        }

        public void setNearPlaneDistance(float nearPlaneDistance) {
            this.nearPlaneDistance = nearPlaneDistance;
        }

        public void setShape(class_6854 shape) {
            this.shape = shape;
        }
    }

    class ColorData {
        private final class_4184 camera;
        private float red;
        private float green;
        private float blue;

        public ColorData(class_4184 camera, float red, float green, float blue) {
            this.camera = camera;
            this.red = red;
            this.green = green;
            this.blue = blue;
        }

        public class_4184 getCamera() {
            return this.camera;
        }

        public float getRed() {
            return this.red;
        }

        public float getGreen() {
            return this.green;
        }

        public float getBlue() {
            return this.blue;
        }

        public void setRed(float red) {
            this.red = red;
        }

        public void setGreen(float green) {
            this.green = green;
        }

        public void setBlue(float blue) {
            this.blue = blue;
        }
    }
}