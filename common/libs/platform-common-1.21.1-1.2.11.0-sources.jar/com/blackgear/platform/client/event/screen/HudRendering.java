package com.blackgear.platform.client.event.screen;

import com.blackgear.platform.client.event.screen.api.ScreenAccess;
import com.blackgear.platform.core.util.event.Event;
import com.blackgear.platform.core.util.event.CancellableResult;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_9779;

@Environment(EnvType.CLIENT)
public interface HudRendering {
    Event<Rendering> RENDERING = Event.create(Rendering.class);
    Event<ScreenPreInitialization> PRE_INITIALIZE = Event.cancellable(ScreenPreInitialization.class);
    Event<ScreenPostInitialization> POST_INITIALIZE = Event.create(ScreenPostInitialization.class);
    Event<ScreenPreRendering> PRE_RENDERING = Event.cancellable(ScreenPreRendering.class);
    Event<ScreenPostRendering> POST_RENDERING = Event.create(ScreenPostRendering.class);
    Event<ContainerRenderBackground> RENDER_BACKGROUND = Event.create(ContainerRenderBackground.class);
    Event<ContainerRenderForeground> RENDER_FOREGROUND = Event.create(ContainerRenderForeground.class);
    Event<OpenContainer> OPEN_CONTAINER = Event.create(OpenContainer.class);
    Event<CloseContainer> CLOSE_CONTAINER = Event.create(CloseContainer.class);

    interface Rendering {
        void onRender(class_310 client, class_332 graphics, class_9779 tracker);
    }

    interface ScreenPreInitialization {
        CancellableResult onInitialize(class_310 client, class_437 screen, ScreenAccess access);
    }

    interface ScreenPostInitialization {
        void onInitialize(class_310 client, class_437 screen, ScreenAccess access);
    }

    interface ScreenPreRendering {
        CancellableResult onRender(class_310 client, class_437 screen, class_332 graphics, int mouseX, int mouseY, class_9779 tracker);
    }

    interface ScreenPostRendering {
        void onRender(class_310 client, class_437 screen, class_332 graphics, int mouseX, int mouseY, class_9779 tracker);
    }

    interface ContainerRenderBackground {
        void onRender(class_310 client, class_465<?> screen, class_332 graphics, int mouseX, int mouseY, class_9779 tickDelta);
    }

    interface ContainerRenderForeground {
        void onRender(class_310 client, class_465<?> screen, class_332 graphics, int mouseX, int mouseY, class_9779 tickDelta);
    }

    interface OpenContainer {
        void onOpen(class_310 client, class_437 screen);
    }

    interface CloseContainer {
        void onClose(class_310 client, class_437 screen);
    }
}