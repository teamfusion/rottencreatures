package com.blackgear.platform.client.event.screen;

import com.blackgear.platform.core.util.event.Event;
import com.blackgear.platform.core.util.event.CancellableResult;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;

@Environment(EnvType.CLIENT)
public interface HudInteractions {
    Event<MouseScroll> SCROLLING_PRE = Event.cancellable(MouseScroll.class);
    Event<MouseScroll> SCROLLING_POST = Event.cancellable(MouseScroll.class);

    Event<MouseClick> CLICKING_PRE = Event.cancellable(MouseClick.class);
    Event<MouseClick> CLICKING_POST = Event.cancellable(MouseClick.class);

    Event<MouseRelease> RELEASING_PRE = Event.cancellable(MouseRelease.class);
    Event<MouseRelease> RELEASING_POST = Event.cancellable(MouseRelease.class);

    Event<SlotClicked> SLOT_CLICK = Event.create(SlotClicked.class);
    Event<StopHovering> STOP_HOVERING = Event.create(StopHovering.class);

    interface SlotClicked {
        void onMouseClick(class_310 client, class_465<?> screen, class_1735 slot, class_1713 clickType);
    }

    interface StopHovering {
        void onStopHovering(class_310 client, class_465<?> screen, class_1735 slot);
    }

    interface MouseScroll {
        CancellableResult onScrolling(class_310 client, class_437 screen, double mouseX, double mouseY, double deltaX, double deltaY);
    }

    interface MouseClick {
        CancellableResult onClicking(class_310 client, class_437 screen, double mouseX, double mouseY, int button);
    }

    interface MouseRelease {
        CancellableResult onReleasing(class_310 client, class_437 screen, double mouseX, double mouseY, int button);
    }
}