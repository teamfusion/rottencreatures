package com.blackgear.platform.client.event.screen.api;

import java.util.List;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

public interface ScreenAccess {
    class_437 screen();

    List<class_6379> narratables();

    List<class_4068> renderables();

    <T extends class_339 & class_4068 & class_6379> T addRenderableWidget(T widget);

    <T extends class_4068> T addRenderableOnly(T listener);

    <T extends class_364 & class_6379> T addWidget(T listener);
}