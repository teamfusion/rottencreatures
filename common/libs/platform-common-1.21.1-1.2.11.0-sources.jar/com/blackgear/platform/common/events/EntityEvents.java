package com.blackgear.platform.common.events;

import com.blackgear.platform.core.util.event.CancellableResult;
import com.blackgear.platform.core.util.event.Event;
import java.util.Arrays;
import java.util.function.Consumer;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public interface EntityEvents {
    Event<LivingSpawn> ON_SPAWN = Event.cancellable(LivingSpawn.class);
    Event<LivingAttack> ON_ATTACK = Event.cancellable(LivingAttack.class);
    Event<LivingDeath> ON_DEATH = Event.cancellable(LivingDeath.class);
    Event<EntityPickUp> ON_PICK = Event.create(EntityPickUp.class);

    interface LivingSpawn {
        CancellableResult onSpawn(class_1297 entity, class_1937 level);
    }

    interface LivingAttack {
        CancellableResult onAttack(class_1297 entity, class_1282 source);
    }

    interface LivingDeath {
        CancellableResult onDeath(class_1297 entity, class_1282 source);
    }

    interface EntityPickUp {
        void onPickUp(class_1297 entity, Consumer<class_1799> stack);
    }
}