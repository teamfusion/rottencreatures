package com.blackgear.platform.common;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_5321;
import net.minecraft.class_7699;

/**
 * Utility class for creating and modifying {@link class_1761}.
 *
 * @author ItsBlackGear
 */
public class CreativeTabs {
    /**
     * <p>Example of creating a creative tab:</p>
     *
     * <pre> {@code
     *
     * CoreRegistry<CreativeModeTab> TABS = CoreRegistry.create(BuiltinRegistries.CREATIVE_MODE_TAB, MOD_ID);
     *
     * ResourceKey<CreativeModeTab> CUSTOM_TAB = TABS.resource(
     *     "custom_tab",
     *     () -> CreativeTabs.create(builder -> {
     *         builder.title(Component.translatable("tab.custom_tab"));
     *         builder.icon(() -> new ItemStack(CUSTOM_ITEM));
     *         builder.displayItems((parameters, output) -> {
     *             output.accept(new ItemStack(CUSTOM_ITEM));
     *         });
     *     }));
     *
     * } </pre>
     *
     * @param consumer the building components of the creative tab
     * @return custom creative tab
     */
    @ExpectPlatform
    public static class_1761 create(Consumer<class_1761.class_7913> consumer) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void modify(class_5321<class_1761> key, Modifier modifier) {
        throw new AssertionError();
    }
    
    public interface Modifier {
        void accept(class_7699 flags, Output output, boolean operator);
    }
    
    public interface Output extends class_1761.class_7704 {
        // ========== DEFAULT ===========
        
        @Override
        default void method_45417(class_1799 stack, class_1761.class_7705 tabVisibility) {
            addAfter(class_1799.field_8037, stack, tabVisibility);
        }
        
        // ========== ADD AFTER ===========
        
        void addAfter(class_1799 target, class_1799 stack, class_1761.class_7705 visibility);
        
        default void addAfter(class_1799 target, class_1799 stack) {
            addAfter(target, stack, class_1761.class_7705.field_40191);
        }

        default void addAfter(class_1935 target, class_1935 stack) {
            addAfter(target.method_8389().method_7854(), stack.method_8389().method_7854(), class_1761.class_7705.field_40191);
        }
        
        default void addAllAfter(class_1799 target, Collection<class_1799> stacks, class_1761.class_7705 visibility) {
            List<class_1799> list = List.copyOf(stacks);
            for (int i = list.size() - 1; i >= 0; i--) this.addAfter(target, list.get(i), visibility);
        }
        
        default void addAllAfter(class_1799 target, Collection<class_1799> stacks) {
            List<class_1799> list = List.copyOf(stacks);
            for (int i = list.size() - 1; i >= 0; i--) this.addAfter(target, list.get(i));
        }

        default void addAllAfter(class_1935 target, Collection<class_1935> stacks) {
            List<class_1935> list = List.copyOf(stacks);
            for (int i = list.size() - 1; i >= 0; i--) this.addAfter(target, list.get(i));
        }
        
        // ========== ADD BEFORE ===========
        
        void addBefore(class_1799 target, class_1799 stack, class_1761.class_7705 visibility);
        
        default void addBefore(class_1799 target, class_1799 stack) {
            addBefore(target, stack, class_1761.class_7705.field_40191);
        }

        default void addBefore(class_1935 target, class_1935 stack) {
            addBefore(target.method_8389().method_7854(), stack.method_8389().method_7854(), class_1761.class_7705.field_40191);
        }
        
        default void addAllBefore(class_1799 target, Collection<class_1799> stacks, class_1761.class_7705 visibility) {
            List<class_1799> list = List.copyOf(stacks);
            for (int i = list.size() - 1; i >= 0; i--) this.addBefore(target, list.get(i), visibility);
        }
        
        default void addAllBefore(class_1799 target, Collection<class_1799> stacks) {
            List<class_1799> list = List.copyOf(stacks);
            for (int i = list.size() - 1; i >= 0; i--) this.addBefore(target, list.get(i));
        }

        default void addAllBefore(class_1935 target, Collection<class_1935> stacks) {
            List<class_1935> list = List.copyOf(stacks);
            for (int i = list.size() - 1; i >= 0; i--) this.addBefore(target, list.get(i));
        }
    }
}