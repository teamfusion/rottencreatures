package com.blackgear.platform.common.item;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_6395;
import org.jetbrains.annotations.Nullable;

public class ItemPropertyRegistry {
    @ExpectPlatform
    public static class_6395 registerGeneric(class_2960 name, class_6395 property) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    public static class_1800 registerGeneric(class_2960 name, class_1800 property) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    public static void registerCustomModelData(class_1800 property) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    public static void register(class_1792 item, class_2960 name, class_6395 property) {
        throw new AssertionError();
    }
    
    @Nullable
    public static class_1800 getProperty(class_1792 item, class_2960 name) {
        return class_5272.method_27878(new class_1799(item), name);
    }
}