package com.blackgear.platform.common.worldgen.modifier;

import java.util.function.BiConsumer;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_6796;

/**
 * Utility class to apply modifications to biomes.
 **/
public abstract class BiomeWriter {
    public void add(BiConsumer<BiomeWriter, BiomeContext> modifier) {
        modifier.accept(this, this.context());
    }

    public abstract class_2960 name();

    public abstract BiomeContext context();

    public abstract void addFeature(class_2893.class_2895 decoration, class_5321<class_6796> feature);

    public abstract void removeFeature(class_2893.class_2895 decoration, class_5321<class_6796> feature);

    public void replaceFeature(class_2893.class_2895 decoration, class_5321<class_6796> feature, class_5321<class_6796> replacement) {
        if (this.context().hasFeature(feature)) {
            this.removeFeature(decoration, feature);
            this.addFeature(decoration, replacement);
        }
    }

    public abstract void addCarver(class_2893.class_2894 carving, class_5321<class_2922<?>> carver);

    public abstract void removeCarver(class_2893.class_2894 carving, class_5321<class_2922<?>> carver);

    public abstract void addSpawn(class_1311 category, class_5483.class_1964 data);

    public abstract void removeSpawn(class_1299<?> data);

    public void replaceSpawn(class_1311 category, class_5483.class_1964 data) {
        if (this.context().hasEntity(() -> data.field_9389)) {
            this.removeSpawn(data.field_9389);
            this.addSpawn(category, data);
        }
    }
}