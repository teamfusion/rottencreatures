package com.blackgear.platform.common.worldgen.placement.parameters;

import net.minecraft.class_6544;

public enum Erosion {
    EROSION_0(class_6544.class_6546.method_38121(-1.0F, -0.78F)),
    EROSION_1(class_6544.class_6546.method_38121(-0.78F, -0.375F)),
    EROSION_2(class_6544.class_6546.method_38121(-0.375F, -0.2225F)),
    EROSION_3(class_6544.class_6546.method_38121(-0.2225F, 0.05F)),
    EROSION_4(class_6544.class_6546.method_38121(0.05F, 0.45F)),
    EROSION_5(class_6544.class_6546.method_38121(0.45F, 0.55F)),
    EROSION_6(class_6544.class_6546.method_38121(0.55F, 1.0F)),
    FULL_RANGE(class_6544.class_6546.method_38121(-1.0F, 1.0F));
    
    private final class_6544.class_6546 parameter;
    
    Erosion(class_6544.class_6546 parameter) {
        this.parameter = parameter;
    }
    
    public class_6544.class_6546 parameter() {
        return this.parameter;
    }
    
    public static class_6544.class_6546 span(Erosion min, Erosion max) {
        return class_6544.class_6546.method_38121(class_6544.method_38666(min.parameter().comp_103()), class_6544.method_38666(max.parameter().comp_104()));
    }
}