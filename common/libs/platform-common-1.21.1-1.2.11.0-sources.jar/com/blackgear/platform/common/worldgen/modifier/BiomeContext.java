package com.blackgear.platform.common.worldgen.modifier;

import com.google.common.collect.ImmutableSet;
import java.util.Arrays;
import java.util.Set;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_6796;
import net.minecraft.class_6862;
import net.minecraft.class_8197;

/**
 * Utility class designed to identify the biome or biomes for implementing biome-specific features.
 **/
public interface BiomeContext {
    Predicate<BiomeContext> OVERWORLD_BIOME = context -> class_8197.class_5305.field_34499.method_49514().anyMatch(context::is);
    
    class_5321<class_1959> resource();
    
    class_1959 biome();
    
    boolean is(class_6862<class_1959> category);
    
    boolean is(class_5321<class_1959> biome);
    
    boolean is(Predicate<BiomeContext> context);

    boolean hasFeature(class_5321<class_6796> feature);

    default boolean hasEntity(Supplier<class_1299<?>> entities) {
        return hasEntity(ImmutableSet.of(entities));
    }
    
    default boolean hasEntity(Set<Supplier<class_1299<?>>> entitySet) {
        Set<class_1299<?>> entities = entitySet.stream()
            .map(Supplier::get)
            .collect(Collectors.toSet());
        
        class_5483 settings = this.biome().method_30966();
        
        return Arrays.stream(class_1311.values())
            .flatMap(category -> settings.method_31004(category).method_34994().stream())
            .anyMatch(spawner -> entities.contains(spawner.field_9389));
    }
}