package com.blackgear.platform.common.worldgen.placement.parameters;

import net.minecraft.class_6544;
import net.minecraft.class_6544.class_6546;

public enum Continentalness {
    MUSHROOM_FIELDS(class_6546.method_38121(-1.2F, -1.05F)),
    DEEP_OCEAN(class_6546.method_38121(-1.05F, -0.455F)),
    OCEAN(class_6546.method_38121(-0.455F, -0.19F)),
    COAST(class_6546.method_38121(-0.19F, -0.11F)),
    NEAR_INLAND(class_6546.method_38121(-0.11F, 0.03F)),
    MID_INLAND(class_6546.method_38121(0.03F, 0.3F)),
    FAR_INLAND(class_6546.method_38121(0.03F, 1.0F)),
    INLAND(class_6546.method_38121(-0.11F, 0.55F)),
    FULL_RANGE(class_6546.method_38121(-1.2F, 1.0F));

    private final class_6546 parameter;
    
    Continentalness(class_6546 parameter) {
        this.parameter = parameter;
    }
    
    public class_6546 parameter() {
        return this.parameter;
    }
    
    public static class_6546 span(Continentalness min, Continentalness max) {
        return class_6546.method_38121(class_6544.method_38666(min.parameter().comp_103()), class_6544.method_38666(max.parameter().comp_104()));
    }
}