package com.blackgear.platform.common.worldgen.placement.parameters;

import net.minecraft.class_6544;
import net.minecraft.class_6544.class_6546;

public enum Depth {
    SURFACE(class_6546.method_38120(0.0F)),
    UNDERGROUND(class_6546.method_38121(0.2F, 0.9F)),
    FLOOR(class_6546.method_38120(1.0F)),
    FULL_RANGE(class_6546.method_38121(-1.0F, 1.0F));
    
    private final class_6546 parameter;
    
    Depth(class_6546 parameter) {
        this.parameter = parameter;
    }
    
    public class_6546 parameter() {
        return this.parameter;
    }
    
    public static class_6546 span(Depth min, Depth max) {
        return class_6546.method_38121(class_6544.method_38666(min.parameter().comp_103()), class_6544.method_38666(max.parameter().comp_104()));
    }
}