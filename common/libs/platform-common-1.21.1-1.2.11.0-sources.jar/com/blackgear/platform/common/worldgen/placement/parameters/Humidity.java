package com.blackgear.platform.common.worldgen.placement.parameters;

import net.minecraft.class_6544;
import net.minecraft.class_6544.class_6546;

public enum Humidity {
    ARID(class_6546.method_38121(-1.0F, -0.35F)),
    DRY(class_6546.method_38121(-0.35F, -0.1F)),
    NEUTRAL(class_6546.method_38121(-0.1F, 0.1F)),
    WET(class_6546.method_38121(0.1F, 0.3F)),
    HUMID(class_6546.method_38121(0.3F, 1.0F)),
    FULL_RANGE(class_6546.method_38121(-1.0F, 1.0F));
    
    private final class_6546 parameter;
    
    Humidity(class_6546 parameter) {
        this.parameter = parameter;
    }
    
    public class_6546 parameter() {
        return this.parameter;
    }
    
    public static class_6546 span(Humidity min, Humidity max) {
        return class_6546.method_38121(class_6544.method_38666(min.parameter().comp_103()), class_6544.method_38666(max.parameter().comp_104()));
    }
}