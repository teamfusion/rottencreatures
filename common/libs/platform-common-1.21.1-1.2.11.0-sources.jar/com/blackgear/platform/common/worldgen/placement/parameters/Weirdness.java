package com.blackgear.platform.common.worldgen.placement.parameters;

import net.minecraft.class_6544;
import net.minecraft.class_6544.class_6546;

public enum Weirdness {
    MID_SLICE_NORMAL_ASCENDING(class_6546.method_38121(-1.0F, -0.93333334F)),
    HIGH_SLICE_NORMAL_ASCENDING(class_6546.method_38121(-0.93333334F, -0.7666667F)),
    PEAK_NORMAL(class_6546.method_38121(-0.7666667F, -0.56666666F)),
    HIGH_SLICE_NORMAL_DESCENDING(class_6546.method_38121(-0.56666666F, -0.4F)),
    MID_SLICE_NORMAL_DESCENDING(class_6546.method_38121(-0.4F, -0.26666668F)),
    LOW_SLICE_NORMAL_DESCENDING(class_6546.method_38121(-0.26666668F, -0.05F)),
    VALLEY(class_6546.method_38121(-0.05F, 0.05F)),
    LOW_SLICE_VARIANT_ASCENDING(class_6546.method_38121(0.05F, 0.26666668F)),
    MID_SLICE_VARIANT_ASCENDING(class_6546.method_38121(0.26666668F, 0.4F)),
    HIGH_SLICE_VARIANT_ASCENDING(class_6546.method_38121(0.4F, 0.56666666F)),
    PEAK_VARIANT(class_6546.method_38121(0.56666666F, 0.7666667F)),
    HIGH_SLICE_VARIANT_DESCENDING(class_6546.method_38121(0.7666667F, 0.93333334F)),
    MID_SLICE_VARIANT_DESCENDING(class_6546.method_38121(0.93333334F, 1.0F)),
    FULL_RANGE(class_6546.method_38121(-1.0F, 1.0F));
    
    private final class_6546 parameter;
    
    Weirdness(class_6546 parameter) {
        this.parameter = parameter;
    }
    
    public class_6546 parameter() {
        return this.parameter;
    }
    
    public static class_6546 span(Weirdness min, Weirdness max) {
        return class_6546.method_38121(class_6544.method_38666(min.parameter().comp_103()), class_6544.method_38666(max.parameter().comp_104()));
    }
}