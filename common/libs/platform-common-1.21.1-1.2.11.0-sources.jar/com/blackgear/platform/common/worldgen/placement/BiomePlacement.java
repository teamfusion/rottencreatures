package com.blackgear.platform.common.worldgen.placement;

import com.blackgear.platform.common.worldgen.placement.parameters.Depth;
import com.blackgear.platform.common.worldgen.placement.parameters.Weirdness;
import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1959;
import net.minecraft.class_5321;
import net.minecraft.class_6544;
import net.minecraft.class_6544.class_4762;
import net.minecraft.class_6544.class_6546;

public class BiomePlacement {
    public static final List<Pair<class_4762, class_5321<class_1959>>> BIOME_PLACEMENTS = Lists.newArrayList();

    public static void registerBiomePlacements(Consumer<Event> listener) {
        listener.accept(BIOME_PLACEMENTS::add);
    }

    public interface Event {
        void add(Pair<class_4762, class_5321<class_1959>> mapper);

        default void addBiome(class_6546 temperature, class_6546 humidity, class_6546 continentalness, class_6546 erosion, class_6546 depth, class_6546 weirdness, float offset, class_5321<class_1959> biome) {
            add(Pair.of(class_6544.method_38118(temperature, humidity, continentalness, erosion, depth, weirdness, class_6544.method_38665(offset)), biome));
        }

        default void addSurfaceBiome(class_6546 temperature, class_6546 humidity, class_6546 continentalness, class_6546 erosion, class_6546 weirdness, float offset, class_5321<class_1959> biome) {
            addBiome(temperature, humidity, continentalness, erosion, Depth.SURFACE.parameter(), weirdness, offset, biome);
            addBiome(temperature, humidity, continentalness, erosion, Depth.FLOOR.parameter(), weirdness, offset, biome);
        }

        default void addUndergroundBiome(class_6546 temperature, class_6546 humidity, class_6546 continentalness, class_6546 erosion, class_6546 weirdness, float offset, class_5321<class_1959> biome) {
            addBiome(temperature, humidity, continentalness, erosion, Depth.UNDERGROUND.parameter(), weirdness, offset, biome);
        }

        default void addBottomBiome(class_6546 temperature, class_6546 humidity, class_6546 continentalness, class_6546 erosion, class_6546 weirdness, float offset, class_5321<class_1959> biome) {
            addBiome(temperature, humidity, continentalness, erosion, Depth.FLOOR.parameter(), weirdness, offset, biome);
        }

        default void addSurfaceBiome(Placement placement, class_6546 temperature, class_6546 humidity, class_6546 continentalness, class_6546 erosion, float offset, class_5321<class_1959> biome) {
            for (Weirdness weirdness : placement.getWeirdnesses()) {
                addSurfaceBiome(temperature, humidity, continentalness, erosion, weirdness.parameter(), offset, biome);
            }
        }
    }
}