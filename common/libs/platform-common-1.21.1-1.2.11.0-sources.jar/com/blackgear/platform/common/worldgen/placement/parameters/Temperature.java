package com.blackgear.platform.common.worldgen.placement.parameters;

import net.minecraft.class_6544;
import net.minecraft.class_6544.class_6546;

public enum Temperature {
    ICY(class_6546.method_38121(-1.0F, -0.45F)),
    COOL(class_6546.method_38121(-0.45F, -0.15F)),
    NEUTRAL(class_6546.method_38121(-0.15F, 0.2F)),
    WARM(class_6546.method_38121(0.2F, 0.55F)),
    HOT(class_6546.method_38121(0.55F, 1.0F)),
    FROZEN(class_6546.method_38121(-1.0F, -0.45F)),
    UNFROZEN(class_6546.method_38121(-0.45F, 1.0F)),
    FULL_RANGE(class_6546.method_38121(-1.0F, 1.0F));
    
    private final class_6546 parameter;
    
    Temperature(class_6546 parameter) {
        this.parameter = parameter;
    }
    
    public class_6546 parameter() {
        return this.parameter;
    }
    
    public static class_6546 span(Temperature min, Temperature max) {
        return class_6546.method_38121(class_6544.method_38666(min.parameter().comp_103()), class_6544.method_38666(max.parameter().comp_104()));
    }
}