package com.blackgear.platform.common.data;

import com.mojang.serialization.Codec;
import java.util.function.Supplier;
import net.minecraft.class_2960;

public interface Attachment<A> {
    class_2960 valueId();

    Codec<A> codec();

    Supplier<A> defaultSyncedValue();
    
    static <A> Attachment<A> create(class_2960 id, Codec<A> codec, Supplier<A> value) {
        return new Attachment<>() {
            @Override
            public class_2960 valueId() {
                return id;
            }

            @Override
            public Codec<A> codec() {
                return codec;
            }

            @Override
            public Supplier<A> defaultSyncedValue() {
                return value;
            }
        };
    }
}