package com.blackgear.platform.common.data;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.ArrayList;
import java.util.Collections;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_79;

/**
 * Utility class to apply modifications to Loot Tables
 *
 * @author ItsBlackGear
 */
public class LootModifier {
    /**
     * Modify an existing loot table.
     *
     * <p>Example of modifying a vanilla loot table:</p>
     *
     * <pre>{@code
     *
     * LootRegistry.modify((lootTables, path, context, builtin) -> {
     *     if (path.equals(BuiltInLootTables.SIMPLE_DUNGEON)) {
     *         LootPool.Builder pool = LootPool.lootPool()
     *             .setRolls(UniformGenerator.between(1.0F, 3.0F))
     *             .add(LootItem.lootTableItem(Items.DIAMOND).setWeight(15));
     *         context.addPool(pool);
     *     }
     * });
     *
     * }</pre>
     *
     * In the example we're currently adding a diamond to the loot table of a simple dungeon.
     */
    @ExpectPlatform
    public static void modify(LootTableModifier modifier) {
        throw new AssertionError();
    }
    
    public interface LootTableModifier {
        void modify(class_5321<class_52> key, LootTableContext context, boolean builtin);
    }
    
    public interface LootTableContext {
        void addPool(class_55.class_56 pool);

        boolean addToPool(int index, ArrayList<class_79> content);

        default boolean addToPool(ArrayList<class_79> content) {
            return this.addToPool(0, content);
        }

        default boolean addToPool(int index, class_79... content) {
            ArrayList<class_79> entries = new ArrayList<>();
            Collections.addAll(entries, content);
            return this.addToPool(index, entries);
        }

        default boolean addToPool(class_79... content) {
            return this.addToPool(0, content);
        }
    }
}