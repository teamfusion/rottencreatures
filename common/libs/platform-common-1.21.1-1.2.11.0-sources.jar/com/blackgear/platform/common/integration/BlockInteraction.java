package com.blackgear.platform.common.integration;

import net.minecraft.class_1269;
import net.minecraft.class_1838;

public interface BlockInteraction {
    class_1269 onUse(class_1838 context);
}