package com.blackgear.platform.common.integration;

import com.google.common.collect.Maps;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1743;
import net.minecraft.class_1821;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2315;
import net.minecraft.class_2357;
import net.minecraft.class_2358;
import net.minecraft.class_2680;
import net.minecraft.world.level.block.*;
import java.util.function.Consumer;

public class BlockIntegration {
    @ExpectPlatform
    public static void registerIntegrations(Consumer<Event> listener) {
        throw new AssertionError();
    }

    public interface Event {
        void registerBlockInteraction(BlockInteraction interaction);

        void registerFuelItem(class_1935 item, int burnTime);

        void registerCompostableItem(class_1935 item, float chance);

        default void registerDispenserBehavior(class_1935 item, class_2357 behavior) {
            class_2315.method_10009(item, behavior);
        }

        default void registerStrippableBlock(class_2248 target, class_2248 result) {
            class_1743.field_7898 = Maps.newHashMap(class_1743.field_7898);
            class_1743.field_7898.putIfAbsent(target, result);
        }

        default void registerFlattenableBlock(class_2248 target, class_2680 result) {
            class_1821.field_8912.putIfAbsent(target, result);
        }

        default void registerFlattenableBlock(class_2248 target, class_2248 result) {
            registerFlattenableBlock(target, result.method_9564());
        }

        default void registerFlammableBlock(class_2248 target, int encouragement, int flammability) {
            ((class_2358) class_2246.field_10036).method_10189(target, encouragement, flammability);
        }
    }
}