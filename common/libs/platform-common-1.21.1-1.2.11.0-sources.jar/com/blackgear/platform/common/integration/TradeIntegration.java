package com.blackgear.platform.common.integration;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.function.Consumer;
import net.minecraft.class_3852;
import net.minecraft.class_3853;

public class TradeIntegration {
    @ExpectPlatform
    public static void registerVillagerTrades(Consumer<Event> listener) {
        throw new AssertionError();
    }

    public interface Event {
        void registerTrade(class_3852 profession, VillagerLevel level, class_3853.class_1652... trades);

        void registerWandererTrade(boolean rare, class_3853.class_1652... trades);
    }
}