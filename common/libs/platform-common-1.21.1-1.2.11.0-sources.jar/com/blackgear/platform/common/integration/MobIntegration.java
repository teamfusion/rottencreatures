package com.blackgear.platform.common.integration;

import com.blackgear.platform.common.events.EntityEvents;
import com.blackgear.platform.core.util.event.CancellableResult;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1317;
import net.minecraft.class_1352;
import net.minecraft.class_2902;
import net.minecraft.class_5132;
import net.minecraft.class_9168;
import net.minecraft.world.entity.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class MobIntegration {
    @ExpectPlatform
    public static void registerIntegrations(Consumer<Event> listener) {
        throw new AssertionError();
    }

    public interface Event {
        void registerMobInteraction(MobInteraction interaction);

        void registerAttributes(Supplier<? extends class_1299<? extends class_1309>> type, Supplier<class_5132.class_5133> builder);

        <T extends class_1308> void registerPlacement(Supplier<class_1299<T>> entity, class_9168 spawnPlacement, class_2902.class_2903 heightmap, class_1317.class_4306<T> spawnPredicate);

        default void registerGoal(Predicate<class_1308> predicate, int priority, Function<class_1308, class_1352> factory) {
            EntityEvents.ON_SPAWN.register((entity, level) -> {
                if (entity instanceof class_1308 mob && predicate.test(mob)) {
                    mob.field_6201.method_6277(priority, factory.apply(mob));
                }

                return CancellableResult.PASS;
            });
        }

        default void registerGoal(class_1299<?> entity, int priority, Function<class_1308, class_1352> factory) {
            registerGoal(mob -> mob.method_5864() == entity, priority, factory);
        }

        default void registerTarget(Predicate<class_1308> predicate, int priority, Function<class_1308, class_1352> factory) {
            EntityEvents.ON_SPAWN.register((entity, level) -> {
                if (entity instanceof class_1308 mob && predicate.test(mob)) {
                    mob.field_6185.method_6277(priority, factory.apply(mob));
                }

                return CancellableResult.PASS;
            });
        }

        default void registerTarget(class_1299<? extends class_1297> entity, int priority, Function<class_1308, class_1352> factory) {
            registerTarget(mob -> mob.method_5864() == entity, priority, factory);
        }
    }
}