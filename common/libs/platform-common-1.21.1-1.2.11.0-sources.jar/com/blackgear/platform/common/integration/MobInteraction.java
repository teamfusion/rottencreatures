package com.blackgear.platform.common.integration;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public interface MobInteraction {
    class_1269 onInteract(class_1657 player, class_1297 entity, class_1268 hand);
}