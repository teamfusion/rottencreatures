package com.blackgear.platform.common.block;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_8177;

public class WoodTypeRegistry {
    @ExpectPlatform
    public static class_4719 create(class_2960 location, class_8177 blockSetType) {
        throw new AssertionError();
    }

    @ExpectPlatform @Environment(EnvType.CLIENT)
    public static void registerWoodType(class_4719 type) {
        throw new AssertionError();
    }
}