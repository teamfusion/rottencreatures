package com.blackgear.platform;

import com.blackgear.platform.client.ClientSetup;
import com.blackgear.platform.common.CommonSetup;
import com.blackgear.platform.common.resource.RegistryAwareJsonReloadListener;
import com.blackgear.platform.common.worldgen.modifier.BiomeManager;
import com.blackgear.platform.core.ModInstance;
import com.blackgear.platform.core.helper.AttachmentRegistry;
import com.blackgear.platform.core.networking.packet.ClientboundConfigSyncPayload;
import com.blackgear.platform.core.networking.Networking;
import com.blackgear.platform.core.util.config.ConfigLoader;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Platform {
	public static final String MOD_ID = "platform";
	public static final Logger LOGGER = LogManager.getLogger(MOD_ID);
	public static final ModInstance INSTANCE = ModInstance.create(MOD_ID)
		.client(ClientSetup::setup)
		.common(CommonSetup::setup)
		.build();

	public static void bootstrap() {
		INSTANCE.bootstrap();

		Networking.register(registrar -> registrar.registerToClient(ClientboundConfigSyncPayload.TYPE, ClientboundConfigSyncPayload.STREAM_CODEC, ClientboundConfigSyncPayload::handler));

		ConfigLoader.bootstrap();
		BiomeManager.bootstrap();
		AttachmentRegistry.bootstrap();
	}

	public static void afterDataReload(class_5455 registryAccess, boolean client) {
		RegistryAwareJsonReloadListener.runReloads(registryAccess);
	}

	public static class_2960 resource(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
}