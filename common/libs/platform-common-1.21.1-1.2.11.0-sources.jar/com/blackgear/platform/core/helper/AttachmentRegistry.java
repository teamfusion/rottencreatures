package com.blackgear.platform.core.helper;

import com.blackgear.platform.common.data.Attachment;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1309;

public class AttachmentRegistry {
    @ExpectPlatform
    public static <T> void register(Attachment<T> attachment) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T> boolean hasAttachment(class_1309 entity, Attachment<T> attachment) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T> T getAttachmentValue(class_1309 entity, Attachment<T> attachment) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T> void setAttachment(class_1309 entity, Attachment<T> attachment, T value) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T> void removeAttachment(class_1309 entity, Attachment<T> attachment) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void bootstrap() {
        throw new AssertionError();
    }
}