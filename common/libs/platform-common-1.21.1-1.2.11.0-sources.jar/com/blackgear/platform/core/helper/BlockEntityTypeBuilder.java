package com.blackgear.platform.core.helper;

import com.mojang.datafixers.types.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public record BlockEntityTypeBuilder<T extends class_2586>(Factory<? extends T> factory, List<Supplier<class_2248>> blocks) {
    public static <T extends class_2586> BlockEntityTypeBuilder<T> create(Factory<? extends T> factory, List<Supplier<class_2248>> blocks) {
        return new BlockEntityTypeBuilder<>(factory, blocks);
    }

    @SafeVarargs
    public static <T extends class_2586> BlockEntityTypeBuilder<T> create(Factory<? extends T> factory, Supplier<class_2248>... blocks) {
        List<Supplier<class_2248>> entries = new ArrayList<>(blocks.length);
        Collections.addAll(entries, blocks);
        return new BlockEntityTypeBuilder<>(factory, entries);
    }

    public BlockEntityTypeBuilder<T> add(Supplier<class_2248> block) {
        this.blocks.add(block);
        return this;
    }

    @SafeVarargs
    public final BlockEntityTypeBuilder<T> add(Supplier<class_2248>... block) {
        Collections.addAll(this.blocks, block);
        return this;
    }

    public class_2591<T> build() {
        return build(null);
    }

    public class_2591<T> build(Type<?> type) {
        return class_2591.class_2592.<T>method_20528(this.factory::create, this.blocks.stream().map(Supplier::get).toArray(class_2248[]::new)).method_11034(type);
    }

    public interface Factory<T extends class_2586> {
        T create(class_2338 origin, class_2680 state);
    }
}