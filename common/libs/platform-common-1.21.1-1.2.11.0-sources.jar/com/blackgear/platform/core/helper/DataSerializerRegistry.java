package com.blackgear.platform.core.helper;

import net.minecraft.class_2941;
import net.minecraft.class_2943;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class DataSerializerRegistry {
    public static DataSerializerRegistry create() {
        return new DataSerializerRegistry();
    }

    public <T> class_2941<T> create(class_9139<? super class_9129, T> codec) {
        return register(class_2941.method_56031(codec));
    }

    public <T> class_2941<T> register(class_2941<T> serializer) {
        class_2943.method_12720(serializer);
        return serializer;
    }

    public void register() {}
}