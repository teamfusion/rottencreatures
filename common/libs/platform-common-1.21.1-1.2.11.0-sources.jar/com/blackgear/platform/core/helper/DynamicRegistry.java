package com.blackgear.platform.core.helper;

import com.mojang.serialization.Codec;
import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.function.Consumer;
import net.minecraft.class_2378;
import net.minecraft.class_5321;

public class DynamicRegistry {
    @ExpectPlatform
    public static void onRegister(Consumer<Registrar> consumer) {
    }

    public interface Registrar {
        <T> void registerDynamicRegistry(class_5321<class_2378<T>> key, Codec<T> codec);
    }
}