package com.blackgear.platform.core.helper;

import com.blackgear.platform.core.CoreRegistry;
import java.util.function.Supplier;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class SoundRegistry {
    private final CoreRegistry<class_3414> sounds;
    private final String modId;

    public static SoundRegistry create(String modId) {
        return new SoundRegistry(modId);
    }

    private SoundRegistry(String modId) {
        this.modId = modId;
        this.sounds = CoreRegistry.create(class_7923.field_41172, this.modId);
    }

    public Supplier<class_3414> soundEvent(String name) {
        return this.sounds.register(name, () -> class_3414.method_47908(class_2960.method_60655(this.modId, name)));
    }

    public class_2498 soundType(
        float volume,
        float pitch,
        Supplier<class_3414> breakSound,
        Supplier<class_3414> stepSound,
        Supplier<class_3414> placeSound,
        Supplier<class_3414> hitSound,
        Supplier<class_3414> fallSound
    ) {
        return new SoundTypeImpl(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);
    }

    public class_2498 soundType(
        Supplier<class_3414> breakSound,
        Supplier<class_3414> stepSound,
        Supplier<class_3414> placeSound,
        Supplier<class_3414> hitSound,
        Supplier<class_3414> fallSound
    ) {
        return soundType(1.0F, 1.0F, breakSound, stepSound, placeSound, hitSound, fallSound);
    }

    public void register() {
        this.sounds.register();
    }

    public CoreRegistry<class_3414> registry() {
        return this.sounds;
    }

    static class SoundTypeImpl extends class_2498 {
        private final Supplier<class_3414> breakSound;
        private final Supplier<class_3414> stepSound;
        private final Supplier<class_3414> placeSound;
        private final Supplier<class_3414> hitSound;
        private final Supplier<class_3414> fallSound;

        public SoundTypeImpl(
            float volume,
            float pitch,
            Supplier<class_3414> breakSound,
            Supplier<class_3414> stepSound,
            Supplier<class_3414> placeSound,
            Supplier<class_3414> hitSound,
            Supplier<class_3414> fallSound
        ) {
            super(volume, pitch, null, null, null, null, null);
            this.breakSound = breakSound;
            this.stepSound = stepSound;
            this.placeSound = placeSound;
            this.hitSound = hitSound;
            this.fallSound = fallSound;
        }

        @Override
        public class_3414 method_10595() {
            return this.breakSound.get();
        }

        @Override
        public class_3414 method_10594() {
            return this.stepSound.get();
        }

        @Override
        public class_3414 method_10598() {
            return this.placeSound.get();
        }

        @Override
        public class_3414 method_10596() {
            return this.hitSound.get();
        }

        @Override
        public class_3414 method_10593() {
            return this.fallSound.get();
        }
    }
}