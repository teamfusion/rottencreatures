package com.blackgear.platform.core.events;

import com.blackgear.platform.core.util.event.Event;
import net.minecraft.class_3222;

public interface DatapackSyncEvents {
    Event<DatapackSyncEvents> EVENT = Event.create(DatapackSyncEvents.class);

    void onSync(class_3222 player);
}