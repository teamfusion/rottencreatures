package com.blackgear.platform.core.events;

import com.blackgear.platform.core.util.event.Event;
import net.minecraft.class_5455;

public interface DataLifecycleEvents {
    Event<DataLifecycleEvents> DATA_RELOAD = Event.create(DataLifecycleEvents.class);

    void onReload(class_5455 access, boolean clientSide);
}