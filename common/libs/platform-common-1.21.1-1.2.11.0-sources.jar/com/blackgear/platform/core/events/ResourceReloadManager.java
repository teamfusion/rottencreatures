package com.blackgear.platform.core.events;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_3302;

public class ResourceReloadManager {
    @ExpectPlatform
    public static void registerClient(Consumer<ListenerEvent> listener) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerServer(Consumer<ListenerEvent> listener) {
        throw new AssertionError();
    }

    public interface ListenerEvent {
        void register(class_2960 id, class_3302 consumer);
    }
}