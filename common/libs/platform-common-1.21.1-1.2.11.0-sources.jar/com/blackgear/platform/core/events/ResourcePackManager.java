package com.blackgear.platform.core.events;

import dev.architectury.injectables.annotations.ExpectPlatform;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_3264;
import net.minecraft.class_3288;

public class ResourcePackManager {
    @ExpectPlatform
    public static void registerPack(Consumer<Event> listener) {
        throw new AssertionError();
    }

    public interface Event {
        void register(class_3264 packType, @Nullable Supplier<class_3288> pack);
    }
}