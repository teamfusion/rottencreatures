package com.blackgear.platform.core.mixin.access;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.function.Supplier;
import net.minecraft.class_4148;
import net.minecraft.class_4149;

@Mixin(class_4149.class)
public interface SensorTypeAccessor {
    @Invoker("<init>")
    static <T extends class_4148<?>> class_4149<T> createSensorType(Supplier<T> supplier) {
        throw new AssertionError();
    }
}