package com.blackgear.platform.core.mixin.access;

import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_918.class)
public interface ItemRendererAccessor {
    @Invoker
    void callRenderModelLists(class_1087 model, class_1799 stack, int combinedLight, int combinedOverlay, class_4587 poseStack, class_4588 buffer);
}
