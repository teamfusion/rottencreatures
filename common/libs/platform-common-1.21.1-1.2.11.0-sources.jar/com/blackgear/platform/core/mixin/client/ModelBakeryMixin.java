package com.blackgear.platform.core.mixin.client;

import com.blackgear.platform.client.GameRendering;
import com.blackgear.platform.client.GameRendering.HandHeldModelEvent.Models;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_2960;

@Mixin(class_1088.class)
public abstract class ModelBakeryMixin {
    @Shadow protected abstract void loadSpecialItemModelAndDependencies(class_1091 modelLocation);
    @Shadow @Final private Map<class_1091, class_1100> topLevelModels;
    @Shadow abstract class_1100 getModel(class_2960 modelLocation);

    @Inject(
        method = "<init>",
        at = @At("RETURN")
    )
    public void addModel(CallbackInfo ci) {
        for (Models models : GameRendering.HAND_HELD_MODELS.values()) {
            this.loadSpecialItemModelAndDependencies(models.handheld());
            class_1100 unbaked = this.topLevelModels.get(models.handheld());
            unbaked.method_45785(this::getModel);
        }
    }
}