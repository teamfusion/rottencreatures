package com.blackgear.platform.core.mixin.common;

import com.blackgear.platform.common.data.DataTransformer;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2960.class)
public class ResourceLocationMixin {
    @Mutable @Shadow @Final private String namespace;
    @Mutable @Shadow @Final private String path;

    @Inject(
        method = "<init>",
        at = @At("TAIL")
    )
    private void onInit(String namespace, String path, CallbackInfo ci) {
        if (!DataTransformer.shouldCheckNamespace()) return;

        class_2960 remapped = DataTransformer.applyTransformsIfPossible(namespace, path);
        if (remapped != null) {
            this.namespace = remapped.method_12836();
            this.path = remapped.method_12832();
        }
    }
}