package com.blackgear.platform.core.mixin.client.emissive;

import com.blackgear.platform.client.v2.emissive.SpriteResourceLoaderContext;
import com.blackgear.platform.client.v2.emissive.EmissiveProperties;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_7764;
import net.minecraft.class_7947;
import net.minecraft.class_7948;

@Mixin(class_7947.class)
public abstract class SpriteResourceLoaderMixin {
    @Inject(
        method = "list",
        at = @At(
            value = "INVOKE",
            target = "Lcom/google/common/collect/ImmutableList;builder()Lcom/google/common/collect/ImmutableList$Builder;",
            remap = false
        ),
        locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void platform$onReloadPost(class_3300 resourceManager, CallbackInfoReturnable<List<Supplier<class_7764>>> cir, Map<class_2960, class_7948.class_7950> contents) {
        SpriteResourceLoaderContext context = SpriteResourceLoaderContext.THREAD_LOCAL.get();
        if (context == null) return;

        String suffix = EmissiveProperties.getSuffix();
        if (suffix == null) return;

        Map<class_2960, class_7948.class_7950> emissiveContents = new Object2ObjectOpenHashMap<>();
        Map<class_2960, class_2960> emissiveMappings = new Object2ObjectOpenHashMap<>();

        contents.entrySet()
            .stream()
            .filter(entry -> !entry.getKey().method_12832().endsWith(suffix))
            .forEach(entry -> {
                class_2960 id = entry.getKey();
                class_2960 emissiveId = id.method_45136(id.method_12832() + suffix);

                if (contents.containsKey(emissiveId)) {
                    emissiveMappings.put(id, emissiveId);
                } else {
                    class_2960 emissive = emissiveId.method_45136("textures/" + emissiveId.method_12832() + ".png");
                    resourceManager.method_14486(emissive).ifPresent(resource -> {
                        emissiveContents.put(emissiveId, supplier -> supplier.loadSprite(emissive, resource));
                        emissiveMappings.put(id, emissiveId);
                    });
                }
            });

        contents.putAll(emissiveContents);
        if (!emissiveMappings.isEmpty()) {
            context.setEmissiveMappings(emissiveMappings);
        }
    }
}