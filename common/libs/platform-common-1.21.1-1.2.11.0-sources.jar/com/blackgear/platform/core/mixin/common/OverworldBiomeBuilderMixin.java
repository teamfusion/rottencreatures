package com.blackgear.platform.core.mixin.common;

import com.blackgear.platform.common.worldgen.placement.BiomePlacement;
import com.blackgear.platform.common.worldgen.placement.BiomeSpawnPlacement;
import com.mojang.datafixers.util.Pair;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;
import net.minecraft.class_1959;
import net.minecraft.class_5321;
import net.minecraft.class_6544;
import net.minecraft.class_6554;

@Mixin(class_6554.class)
public class OverworldBiomeBuilderMixin {
    @Inject(
        method = "addBiomes",
        at = @At("TAIL")
    )
    private void platform$addBiomes(Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> mapper, CallbackInfo ci) {
        BiomeSpawnPlacement.BIOME_ENTRIES.forEach(mapper);
        BiomePlacement.BIOME_PLACEMENTS.forEach(mapper);
    }
}