package com.blackgear.platform.core.mixin.access;

import net.minecraft.class_2400;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2400.class)
public interface SimpleParticleTypeAccessor {
    @Invoker("<init>")
    static class_2400 createSimpleParticleType(boolean overrideLimiter) {
        throw new AssertionError();
    }
}