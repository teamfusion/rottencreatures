package com.blackgear.platform.core.mixin.access;

import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4184.class_6355.class)
public interface NearPlaneAccessor {
    @Accessor
    class_243 getForward();
}
