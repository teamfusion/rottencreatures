package com.blackgear.platform.core.mixin.client.emissive;

import com.blackgear.platform.client.v2.emissive.EmissiveModelReloader;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_1088;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import net.minecraft.class_4724;

@Mixin(class_1092.class)
public class ModelManagerMixin {
    @Unique @Nullable private volatile EmissiveModelReloader reloader;

    @Inject(
        method = "reload",
        at = @At("HEAD")
    )
    private void platform$onReloadPre(class_3302.class_4045 preparationBarrier, class_3300 manager, class_3695 preparationsProfiler, class_3695 reloadProfiler, Executor backgroundExecutor, Executor gameExecutor, CallbackInfoReturnable<CompletableFuture<Void>> cir) {
        this.reloader = new EmissiveModelReloader(manager);

        EmissiveModelReloader reloader = this.reloader;
        if (reloader != null) reloader.setContext();
    }

    @Inject(
        method = "reload",
        at = @At("RETURN")
    )
    private void platform$onReload(CallbackInfoReturnable<CompletableFuture<Void>> cir) {
        EmissiveModelReloader reloader = this.reloader;
        if (reloader != null) reloader.clearContext();
    }

    @ModifyReturnValue(
        method = "reload",
        at = @At("RETURN")
    )
    private CompletableFuture<Void> platform$onReloadPost(CompletableFuture<Void> original) {
        return original.thenRun(() -> this.reloader = null);
    }

    @Inject(
        method = "loadModels",
        at = @At("HEAD")
    )
    private void platform$onBakePre(class_3695 profiler, Map<class_2960, class_4724.class_7774> atlasPreparations, class_1088 bakery, CallbackInfoReturnable<?> cir) {
        EmissiveModelReloader reloader = this.reloader;
        if (reloader != null) reloader.beforeBaking(bakery);
    }
}