package com.blackgear.platform.core.mixin.access;

import net.minecraft.class_5218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_5218.class)
public interface LevelResourceAccessor {
    @Invoker("<init>")
    static class_5218 createLevelResource(String string) {
        throw new UnsupportedOperationException();
    }
}
