package com.blackgear.platform.core.mixin.config;

import com.blackgear.platform.core.util.config.ConfigTracker;
import net.minecraft.class_2899;
import net.minecraft.class_310;
import net.minecraft.class_635;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_635.class)
public class ClientHandshakePacketListenerImplMixin {
    @Shadow @Final private class_310 minecraft;
    @Unique private boolean hasLoadedConfigs;

    @Inject(method = "handleCustomQuery", at = @At("HEAD"))
    public void handleCustomQuery(class_2899 packet, CallbackInfo ci) {
        if (!this.hasLoadedConfigs && !this.minecraft.method_1496()) {
            ConfigTracker.INSTANCE.loadDefaultServerConfigs();
            this.hasLoadedConfigs = true;
        }
    }
}