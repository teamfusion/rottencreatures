package com.blackgear.platform.core.mixin.client.emissive;

import com.blackgear.platform.client.v2.emissive.SpriteResourceLoaderContext;
import com.blackgear.platform.client.v2.emissive.EmissiveSpriteHolder;
import com.blackgear.platform.client.v2.emissive.EmissiveSpriteLoader;
import com.blackgear.platform.client.v2.emissive.SpriteLoaderStitchContext;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1058;
import net.minecraft.class_2960;
import net.minecraft.class_7764;
import net.minecraft.class_7766;

@Mixin(class_7766.class)
public class SpriteLoaderMixin {
    @Shadow @Final private class_2960 location;

    @ModifyArg(
        method = "loadAndStitch(Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/resources/ResourceLocation;ILjava/util/concurrent/Executor;Ljava/util/Collection;)Ljava/util/concurrent/CompletableFuture;",
        at = @At(
            value = "INVOKE",
            target = "Ljava/util/concurrent/CompletableFuture;supplyAsync(Ljava/util/function/Supplier;Ljava/util/concurrent/Executor;)Ljava/util/concurrent/CompletableFuture;",
            ordinal = 0
        ),
        index = 0
    )
    private Supplier<List<Supplier<class_7764>>> platform$wrapContents(Supplier<List<Supplier<class_7764>>> contents) {
        EmissiveSpriteLoader context = EmissiveSpriteLoader.THREAD_LOCAL.get();
        if (context == null) return contents;

        EmissiveSpriteLoader.Controller control = context.getController(location);
        if (control == null) return contents;

        return () -> {
            SpriteResourceLoaderContext.THREAD_LOCAL.set(control::setEmissiveMappings);
            try {
                return contents.get();
            } finally {
                SpriteResourceLoaderContext.THREAD_LOCAL.remove();
            }
        };
    }

    @ModifyArg(
        method = "loadAndStitch(Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/resources/ResourceLocation;ILjava/util/concurrent/Executor;Ljava/util/Collection;)Ljava/util/concurrent/CompletableFuture;",
        at = @At(
            value = "INVOKE",
            target = "Ljava/util/concurrent/CompletableFuture;thenApply(Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture;",
            ordinal = 0
        ),
        index = 0
    )
    private Function<List<class_7764>, class_7766.class_7767> platform$wrapPreparations(Function<List<class_7764>, class_7766.class_7767> preparations) {
        EmissiveSpriteLoader context = EmissiveSpriteLoader.THREAD_LOCAL.get();
        if (context == null) return preparations;

        EmissiveSpriteLoader.Controller control = context.getController(this.location);
        if (control == null) return preparations;

        return contents -> {
            Map<class_2960, class_2960> emissiveMappings = control.getEmissiveMappings();
            if (emissiveMappings == null) return preparations.apply(contents);

            SpriteLoaderStitchContext stitch = new SpriteLoaderStitchContext() {
                @Override
                public Map<class_2960, class_2960> getEmissiveMappings() {
                    return emissiveMappings;
                }

                @Override
                public void markHasEmissives() {
                    control.markHasEmissives();
                }
            };

            SpriteLoaderStitchContext.THREAD_LOCAL.set(stitch);
            try {
                return preparations.apply(contents);
            } finally {
                SpriteLoaderStitchContext.THREAD_LOCAL.remove();
            }
        };
    }

    @Inject(
        method = "stitch",
        at = @At("RETURN")
    )
    private void platform$linkEmissiveSprites(List<class_7764> spriteContentsList, int mipmapLevels, Executor executor, CallbackInfoReturnable<class_7766.class_7767> cir) {
        SpriteLoaderStitchContext context = SpriteLoaderStitchContext.THREAD_LOCAL.get();
        if (context == null) return;

        Map<class_2960, class_2960> emissiveMappings = context.getEmissiveMappings();
        Map<class_2960, class_1058> sprites = cir.getReturnValue().comp_1044();

        emissiveMappings.forEach((id, emissiveId) -> {
            class_1058 originalSprite = sprites.get(id);
            if (originalSprite == null) return;

            class_1058 emissiveSprite = sprites.get(emissiveId);
            if (emissiveSprite != null) {
                ((EmissiveSpriteHolder) originalSprite).setEmissiveSprite(emissiveSprite);
                context.markHasEmissives();
            }
        });
    }
}