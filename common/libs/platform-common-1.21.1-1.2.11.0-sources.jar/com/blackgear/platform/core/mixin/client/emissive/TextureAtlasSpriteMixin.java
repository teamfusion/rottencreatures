package com.blackgear.platform.core.mixin.client.emissive;

import com.blackgear.platform.client.v2.emissive.EmissiveSpriteHolder;
import net.minecraft.class_1058;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_1058.class)
public class TextureAtlasSpriteMixin implements EmissiveSpriteHolder {
    @Unique private class_1058 emissiveSprite;

    @Override
    public @Nullable class_1058 getEmissiveSprite() {
        return this.emissiveSprite;
    }

    @Override
    public void setEmissiveSprite(class_1058 sprite) {
        this.emissiveSprite = sprite;
    }
}