package com.blackgear.platform.core.mixin.client;

import com.blackgear.platform.client.GameRendering;
import com.blackgear.platform.client.GameRendering.HandHeldModelEvent.Models;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_763;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_918.class)
public abstract class ItemRendererMixin {
    @Shadow @Final private class_763 itemModelShaper;

    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true)
    private class_1087 render(class_1087 original, class_1799 stack, class_811 context) {
        boolean isGuiModel = context == class_811.field_4317 || context == class_811.field_4318 || context == class_811.field_4319;
        if (isGuiModel) {
            if (GameRendering.HAND_HELD_MODELS.get(stack.method_7909()) != null) {
                Models models = GameRendering.HAND_HELD_MODELS.get(stack.method_7909());
                return this.itemModelShaper.method_3303().method_4742(models.original());
            }
        }

        return original;
    }

    @ModifyVariable(method = "getModel", at = @At(value = "STORE"))
    private class_1087 getModel(class_1087 original, class_1799 stack) {
        if (GameRendering.HAND_HELD_MODELS.get(stack.method_7909()) != null) {
            Models models = GameRendering.HAND_HELD_MODELS.get(stack.method_7909());
            return this.itemModelShaper.method_3303().method_4742(models.handheld());
        }

        return original;
    }
}