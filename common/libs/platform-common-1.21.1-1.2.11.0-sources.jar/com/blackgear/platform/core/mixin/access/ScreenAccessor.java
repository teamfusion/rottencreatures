package com.blackgear.platform.core.mixin.access;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

@Mixin(class_437.class)
public interface ScreenAccessor {
    @Accessor
    List<class_6379> getNarratables();

    @Accessor
    List<class_4068> getRenderables();

    @Invoker
    <T extends class_364 & class_4068 & class_6379> T callAddRenderableWidget(T widget);

    @Invoker
    <T extends class_4068> T callAddRenderableOnly(T renderable);

    @Invoker
    <T extends class_364 & class_6379>  T callAddWidget(T listener);
}