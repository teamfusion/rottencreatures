package com.blackgear.platform.core.mixin.client;

import com.blackgear.platform.common.events.EntityEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Shadow @Nullable public class_239 hitResult;
    @Shadow @Nullable public class_746 player;
    @Shadow @Nullable public class_636 gameMode;

    @Inject(
        method = "pickBlock",
        at = @At("HEAD"),
        cancellable = true
    )
    private void platform$pickUpEntity(CallbackInfo ci) {
        if (this.hitResult != null && this.hitResult.method_17783() == class_239.class_240.field_1331) {
            boolean isCreative = this.player.method_31549().field_7477;
            final class_1799[] pickResult = { class_1799.field_8037 };

            if (!isCreative) return;

            class_1297 entity = ((class_3966) this.hitResult).method_17782();

            EntityEvents.ON_PICK.invoker().onPickUp(entity, stack -> pickResult[0] = stack);

            if (!pickResult[0].method_7960()) {
                class_1661 inventory = this.player.method_31548();
                inventory.method_7374(pickResult[0]);
                this.gameMode.method_2909(this.player.method_5998(class_1268.field_5808), 36 + inventory.field_7545);
                ci.cancel();
            }
        }
    }
}