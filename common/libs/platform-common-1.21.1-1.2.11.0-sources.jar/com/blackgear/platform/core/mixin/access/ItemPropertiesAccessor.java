package com.blackgear.platform.core.mixin.access;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1800;
import net.minecraft.class_2960;
import net.minecraft.class_5272;

@Mixin(class_5272.class)
public interface ItemPropertiesAccessor {
    @Accessor
    static Map<class_2960, class_1800> getGENERIC_PROPERTIES() {
        throw new UnsupportedOperationException();
    }
}
