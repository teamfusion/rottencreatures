package com.blackgear.platform.core.mixin.client;

import com.blackgear.platform.client.event.FovRendering;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerMixin extends class_1657 {
    public AbstractClientPlayerMixin(class_1937 level, class_2338 pos, float yRot, GameProfile gameProfile) {
        super(level, pos, yRot, gameProfile);
    }

    @Inject(
        method = "getFieldOfViewModifier",
        at = @At(
            value = "RETURN",
            ordinal = 1
        ),
        cancellable = true,
        locals = LocalCapture.CAPTURE_FAILHARD
    )
    public void updateFov(CallbackInfoReturnable<Float> cir, float currentFov) {
        float fov = FovRendering.EVENT.invoker().setFov(this, currentFov);
        if (fov != currentFov) cir.setReturnValue(fov);
    }
}