package com.blackgear.platform.core.mixin.access;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_3283;
import net.minecraft.class_3285;

@Mixin(class_3283.class)
public interface PackRepositoryAccessor {
    @Accessor("sources") Set<class_3285> getSources();
    @Mutable @Accessor("sources") void setSources(Set<class_3285> sources);
}