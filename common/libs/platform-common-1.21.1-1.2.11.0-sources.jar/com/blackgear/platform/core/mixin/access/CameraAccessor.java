package com.blackgear.platform.core.mixin.access;

import net.minecraft.class_1922;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4184.class)
public interface CameraAccessor {
    @Accessor
    class_1922 getLevel();
}