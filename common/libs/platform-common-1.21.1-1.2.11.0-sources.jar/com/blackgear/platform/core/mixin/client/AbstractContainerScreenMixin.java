package com.blackgear.platform.core.mixin.client;

import com.blackgear.platform.client.event.screen.HudInteractions;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public class AbstractContainerScreenMixin<T extends class_1703> {
    @Shadow @Final protected T menu;
    @Shadow @Nullable protected class_1735 hoveredSlot;

    @Inject(
        method = "render",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screens/inventory/AbstractContainerScreen;renderLabels(Lnet/minecraft/client/gui/GuiGraphics;II)V"
        )
    )
    private void platform$stopHoveringOnRender(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        for (int i = 0; i < this.menu.field_7761.size(); i++) {
            class_1735 slot = this.menu.method_7611(i);
            if (slot != this.hoveredSlot) {
                HudInteractions.STOP_HOVERING.invoker().onStopHovering(class_310.method_1551(), (class_465<?>) (Object) this, slot);
            }
        }
    }

    @Inject(
        method = "onClose",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/player/LocalPlayer;closeContainer()V",
            shift = At.Shift.AFTER
        )
    )
    private void platform$stopHoveringOnClose(CallbackInfo ci) {
        if (this.hoveredSlot != null) {
            HudInteractions.STOP_HOVERING.invoker().onStopHovering(class_310.method_1551(), (class_465<?>) (Object) this, this.hoveredSlot);
        }
    }

    @Inject(
        method = "slotClicked",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;handleInventoryMouseClick(IIILnet/minecraft/world/inventory/ClickType;Lnet/minecraft/world/entity/player/Player;)V"
        )
    )
    private void platform$onSlotClick(class_1735 slot, int slotId, int mouseButton, class_1713 type, CallbackInfo ci) {
        HudInteractions.SLOT_CLICK.invoker().onMouseClick(class_310.method_1551(), (class_465<?>) (Object) this, slot, type);
    }
}