package com.blackgear.platform.core.mixin.access;

import net.minecraft.class_4168;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4168.class)
public interface ActivityAccessor {
    @Invoker("<init>")
    static class_4168 createActivity(String name) {
        throw new AssertionError();
    }
}