package com.blackgear.platform.core;

import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;

public interface RegistryHolder<T> extends Supplier<T> {
    @Override
    T get();

    default Optional<T> asOptional() {
        return this.isPresent() ? Optional.of(this.get()) : Optional.empty();
    }

    Optional<class_6880<T>> getHolder();

    boolean isPresent();

    class_2960 getId();

    class_5321<T> getKey();
}