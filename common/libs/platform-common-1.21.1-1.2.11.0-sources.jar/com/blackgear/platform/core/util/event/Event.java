package com.blackgear.platform.core.util.event;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

@SuppressWarnings({"unchecked", "SuspiciousInvocationHandlerImplementation"})
public abstract class Event<T> {
    private static final Map<Method, MethodHandle> METHOD_HANDLE_CACHE = new ConcurrentHashMap<>();
    private static final MethodHandles.Lookup LOOKUP = MethodHandles.lookup();

    protected volatile T invoker;

    public T invoker() {
        return this.invoker;
    }

    public abstract void register(T listener);

    public static <T> Event<T> create(Class<? super T> clazz, Function<T[], T> factory) {
        return new SimpleEvent<>(clazz, factory);
    }

    public static <T> Event<T> create(Class<? super T> type) {
        Class<?>[] interfaces = new Class<?>[] { type };
        ClassLoader classLoader = Event.class.getClassLoader();

        return create(type, callbacks -> (T) Proxy.newProxyInstance(classLoader, interfaces, (proxy, method, args) -> {
            for (Object callback : callbacks) {
                invokeFast(callback, method, args);
            }
            return null;
        }));
    }

    public static <T> Event<T> cancellable(Class<? super T> type) {
        Class<?>[] interfaces = new Class<?>[] { type };
        ClassLoader classLoader = Event.class.getClassLoader();

        return create(type, callbacks -> (T) Proxy.newProxyInstance(classLoader, interfaces, (proxy, method, args) -> {
            for (Object callback : callbacks) {
                CancellableResult result = Objects.requireNonNull(invokeFast(callback, method, args));
                if (result.isCancelled()) {
                    return result;
                }
            }
            return CancellableResult.pass();
        }));
    }

    private static <T, S> S invokeFast(T callback, Method method, Object[] args) throws Throwable {
        MethodHandle handle = METHOD_HANDLE_CACHE.computeIfAbsent(method, m -> {
            try {
                return LOOKUP.unreflect(m);
            } catch (IllegalAccessException e) {
                throw new RuntimeException("Failed to create MethodHandle for " + m, e);
            }
        });

        return (S) (args == null || args.length == 0
            ? handle.invoke(callback)
            : handle.bindTo(callback).invokeWithArguments(args));
    }
}