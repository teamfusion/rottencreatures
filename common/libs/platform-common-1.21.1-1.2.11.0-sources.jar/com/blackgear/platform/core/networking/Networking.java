package com.blackgear.platform.core.networking;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class Networking {
    @ExpectPlatform
    public static void register(Consumer<Registrar> listener) {
        throw new AssertionError();
    }

    public interface Registrar {
        <T extends class_8710> void registerToServer(class_8710.class_9154<T> type, class_9139<? super class_9129, T> codec, BiConsumer<T, PayloadContext> handler);

        <T extends class_8710> void registerToClient(class_8710.class_9154<T> type, class_9139<? super class_9129, T> codec, BiConsumer<T, PayloadContext> handler);

        default <T extends class_8710> void registerBidirectional(class_8710.class_9154<T> type, class_9139<? super class_9129, T> codec, BiConsumer<T, PayloadContext> handler) {
            registerToServer(type, codec, handler);
            registerToClient(type, codec, handler);
        }
    }
}