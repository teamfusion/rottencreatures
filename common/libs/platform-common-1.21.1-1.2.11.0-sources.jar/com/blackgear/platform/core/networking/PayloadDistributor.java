package com.blackgear.platform.core.networking;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import org.jetbrains.annotations.Nullable;

public class PayloadDistributor {
    @ExpectPlatform
    public static void sendToServer(class_8710 packetPayload) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToPlayer(class_3222 player, class_8710 payload) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToPlayersInDimension(class_3218 level, class_8710 payload) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToPlayersNear(class_3218 level, @Nullable class_3222 excluded, double x, double y, double z, double radius, class_8710 payload) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToAllPlayers(class_8710 payload) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToPlayersTrackingEntity(class_1297 entity, class_8710 payload) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToPlayersTrackingChunk(class_3218 level, class_1923 pos, class_8710 payload) {
        throw new AssertionError();
    }
}