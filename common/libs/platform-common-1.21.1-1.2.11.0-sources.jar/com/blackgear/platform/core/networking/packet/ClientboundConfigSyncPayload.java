package com.blackgear.platform.core.networking.packet;

import com.blackgear.platform.Platform;
import com.blackgear.platform.core.networking.PayloadContext;
import com.blackgear.platform.core.util.config.ConfigTracker;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ClientboundConfigSyncPayload(String name, byte[] data) implements class_8710 {
    public static final class_8710.class_9154<ClientboundConfigSyncPayload> TYPE = new class_9154<>(Platform.resource("clientbound_config_sync"));
    public static final class_9139<class_9129, ClientboundConfigSyncPayload> STREAM_CODEC = class_9139.method_56435(
        class_9135.field_48554, ClientboundConfigSyncPayload::name,
        class_9135.field_48987, ClientboundConfigSyncPayload::data,
        ClientboundConfigSyncPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static void handler(ClientboundConfigSyncPayload payload, PayloadContext context) {
        context.enqueueWork(() -> ConfigTracker.INSTANCE.receiveSyncedConfig(payload));
    }
}