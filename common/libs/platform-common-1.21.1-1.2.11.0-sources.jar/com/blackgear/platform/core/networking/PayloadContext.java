package com.blackgear.platform.core.networking;

import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import net.minecraft.class_1657;

public interface PayloadContext {
    class_1657 player();

    CompletableFuture<Void> enqueueWork(Runnable runnable);

    <T> CompletableFuture<T> enqueueWork(Supplier<T> future);
}