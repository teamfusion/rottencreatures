package com.blackgear.platform.core.networking;

import com.blackgear.platform.core.util.event.Event;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;

public interface ServerListenerEvents {
    Event<ServerListenerEvents> JOIN = Event.create(ServerListenerEvents.class);

    void listener(class_3244 connection, MinecraftServer player);
}