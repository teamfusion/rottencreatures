package com.blackgear.platform.client.v2.emissive.neoforge;

import com.blackgear.platform.client.v2.emissive.EmissiveModelWrapperHolder;
import com.blackgear.platform.client.v2.emissive.EmissiveModelWrapper;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.neoforge.client.event.ModelEvent;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmissiveModelWrapperImpl {
    public static void bootstrap() {
        IEventBus bus = ModLoadingContext.get().getActiveContainer().getEventBus();
        if (bus == null) return;

        bus.addListener((ModelEvent.ModifyBakingResult event) -> {
            @Nullable EmissiveModelWrapper handler = ((EmissiveModelWrapperHolder) event.getModelBakery()).getModelWrapper();
            if (handler == null) return;

            Map<ModelResourceLocation, BakedModel> toReplace = new HashMap<>();

            event.getModels().forEach((id, original) -> {
                if (!"minecraft".equals(id.id().getNamespace())) return;

                if (original == null || original instanceof ForgeEmissiveLayerBakedModel) return;
                if (original.isCustomRenderer()) return;

                try {
                    List<BakedModel> renderPasses = original.getRenderPasses(ItemStack.EMPTY, false);
                    if (renderPasses.size() > 1) return;
                } catch (Exception e) {
                    return;
                }

                if (ForgeEmissiveLayerBakedModel.hasEmissiveSprites(original)) {
                    toReplace.put(id, handler.wrap(original, id.id()));
                }
            });

            event.getModels().putAll(toReplace);
        });
    }

    public static BakedModel getBakedModel(BakedModel model) {
        return new ForgeEmissiveLayerBakedModel(model);
    }
}