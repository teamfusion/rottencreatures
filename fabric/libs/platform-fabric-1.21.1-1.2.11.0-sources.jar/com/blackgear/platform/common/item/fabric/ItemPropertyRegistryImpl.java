package com.blackgear.platform.common.item.fabric;

import com.blackgear.platform.core.mixin.access.ItemPropertiesAccessor;
import net.minecraft.class_1792;
import net.minecraft.class_1800;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_6395;

public class ItemPropertyRegistryImpl {
    public static class_6395 registerGeneric(class_2960 name, class_6395 property) {
        return class_5272.method_27881(name, property);
    }
    
    public static class_1800 registerGeneric(class_2960 name, class_1800 property) {
        ItemPropertiesAccessor.getGENERIC_PROPERTIES().put(name, property);
        return property;
    }
    
    public static void registerCustomModelData(class_1800 property) {
        class_5272.method_37106(property);
    }
    
    public static void register(class_1792 item, class_2960 name, class_6395 property) {
        class_5272.method_27879(item, name, property);
    }
}