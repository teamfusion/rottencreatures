package com.blackgear.platform.common.fabric;

import com.blackgear.platform.common.CreativeTabs;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_5321;
import java.util.List;
import java.util.function.Consumer;

public class CreativeTabsImpl {
    public static class_1761 create(Consumer<class_1761.class_7913> consumer) {
        class_1761.class_7913 builder = FabricItemGroup.builder();
        consumer.accept(builder);
        return builder.method_47324();
    }
    
    public static void modify(class_5321<class_1761> key, CreativeTabs.Modifier modifier) {
        ItemGroupEvents.modifyEntriesEvent(key).register(entries -> {
            modifier.accept(
                entries.getEnabledFeatures(),
                new CreativeTabs.Output() {
                    @Override
                    public void addAfter(class_1799 target, class_1799 stack, class_1761.class_7705 visibility) {
                        if (target.method_7960()) {
                            entries.method_45417(stack, visibility);
                        } else {
                            entries.addAfter(target, List.of(stack), visibility);
                        }
                    }

                    @Override
                    public void addBefore(class_1799 target, class_1799 stack, class_1761.class_7705 visibility) {
                        if (target.method_7960()) {
                            entries.method_45417(stack, visibility);
                        } else {
                            entries.addBefore(target, List.of(stack), visibility);
                        }
                    }
                },
                entries.shouldShowOpRestrictedItems()
            );
        });
    }
}