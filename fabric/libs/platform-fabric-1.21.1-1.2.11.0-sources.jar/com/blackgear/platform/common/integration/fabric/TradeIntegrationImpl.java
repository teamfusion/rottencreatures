package com.blackgear.platform.common.integration.fabric;

import com.blackgear.platform.common.integration.TradeIntegration;
import com.blackgear.platform.common.integration.VillagerLevel;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.class_3852;
import net.minecraft.class_3853;
import java.util.Collections;
import java.util.function.Consumer;

public class TradeIntegrationImpl {
    public static void registerVillagerTrades(Consumer<TradeIntegration.Event> listener) {
        listener.accept(new TradeIntegration.Event() {
            @Override
            public void registerTrade(class_3852 profession, VillagerLevel level, class_3853.class_1652... trades) {
                TradeOfferHelper.registerVillagerOffers(profession, level.getValue(), listings -> Collections.addAll(listings, trades));
            }

            @Override
            public void registerWandererTrade(boolean rare, class_3853.class_1652... trades) {
                TradeOfferHelper.registerWanderingTraderOffers(rare ? 2 : 1, listings -> Collections.addAll(listings, trades));
            }
        });
    }
}