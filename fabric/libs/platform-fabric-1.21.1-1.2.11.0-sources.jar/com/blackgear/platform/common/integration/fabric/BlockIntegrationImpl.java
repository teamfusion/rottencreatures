package com.blackgear.platform.common.integration.fabric;

import com.blackgear.platform.common.integration.BlockIntegration;
import com.blackgear.platform.common.integration.BlockInteraction;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.registry.CompostingChanceRegistry;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.class_1838;
import net.minecraft.class_1935;
import java.util.function.Consumer;

public class BlockIntegrationImpl {
    public static void registerIntegrations(Consumer<BlockIntegration.Event> listener) {
        listener.accept(new BlockIntegration.Event() {
            @Override
            public void registerBlockInteraction(BlockInteraction interaction) {
                UseBlockCallback.EVENT.register((player, level, hand, hit) -> interaction.onUse(new class_1838(player, hand, hit)));
            }

            @Override
            public void registerFuelItem(class_1935 item, int burnTime) {
                FuelRegistry.INSTANCE.add(item, burnTime);
            }

            @Override
            public void registerCompostableItem(class_1935 item, float chance) {
                CompostingChanceRegistry.INSTANCE.add(item, chance);
            }
        });
    }
}