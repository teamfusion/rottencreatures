package com.blackgear.platform.common.data.fabric;

import com.blackgear.platform.Platform;
import com.blackgear.platform.common.data.LootModifier;
import com.blackgear.platform.core.mixin.fabric.loot.LootTableBuilderAccessor;
import com.google.common.collect.ImmutableList;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_55;
import net.minecraft.class_79;
import java.util.ArrayList;

public class LootModifierImpl {
    public static void modify(LootModifier.LootTableModifier modifier) {
        LootTableEvents.MODIFY.register((key, table, source, provider) -> {
            modifier.modify(
                key,
                new LootModifier.LootTableContext() {
                    @Override
                    public void addPool(class_55.class_56 pool) {
                        table.method_336(pool);
                    }

                    @Override
                    public boolean addToPool(int index, ArrayList<class_79> content) {
                        try {
                            ImmutableList.Builder<class_55> pools = ((LootTableBuilderAccessor) table).getPools();
                            ImmutableList<class_55> local = pools.build();

                            if (local.size() <= index) {
                                Platform.LOGGER.error("Failed to add content to loot pool at index {}: No pools found", index);
                                return false;
                            }

                            class_55 pool = local.get(index);
                            class_55 modifiedPool = ((LootPoolAccess) pool).mergeEntries(content);

                            ImmutableList.Builder<class_55> builder = ImmutableList.builder();
                            for (int i = 0; i < local.size(); i++) {
                                builder.add(i == index ? modifiedPool : local.get(i));
                            }

                            ((LootTableBuilderAccessor) table).setPools(builder);
                            return true;
                        } catch (Throwable t) {
                            Platform.LOGGER.error("Failed to add content to loot pool at index {}: {}", index, t.getMessage(), t);
                            return false;
                        }
                    }
                },
                source.isBuiltin()
            );
        });
    }
}