package com.blackgear.platform.common.data.fabric;

import java.util.List;
import net.minecraft.class_55;
import net.minecraft.class_79;

public interface LootPoolAccess {
    class_55 mergeEntries(List<class_79> entries);
}