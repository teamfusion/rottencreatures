package com.blackgear.platform.common.block.fabric;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.object.builder.v1.block.type.WoodTypeBuilder;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_8177;

public class WoodTypeRegistryImpl {
    public static class_4719 create(class_2960 location, class_8177 blockSetType) {
        return WoodTypeBuilder.copyOf(class_4719.field_21676).register(location, blockSetType);
    }

    @Environment(EnvType.CLIENT)
    public static void registerWoodType(class_4719 type) {
    }
}