package com.blackgear.platform.core.helper.fabric;

import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1792;
import net.minecraft.class_1826;

public class ItemRegistryImpl {
    public static <T extends class_1308> class_1792 createSpawnEgg(Supplier<class_1299<T>> entity, int primaryColor, int secondaryColor, class_1792.class_1793 properties) {
        return new class_1826(entity.get(), primaryColor, secondaryColor, properties);
    }
}