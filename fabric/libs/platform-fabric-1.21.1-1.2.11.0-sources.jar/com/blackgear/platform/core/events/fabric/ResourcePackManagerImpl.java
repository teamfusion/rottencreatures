package com.blackgear.platform.core.events.fabric;

import com.blackgear.platform.core.Environment;
import com.blackgear.platform.core.events.ResourcePackManager;
import com.blackgear.platform.core.mixin.access.PackRepositoryAccessor;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3285;
import net.minecraft.class_3288;

public class ResourcePackManagerImpl {
    private static final Map<class_3264, List<Supplier<class_3288>>> PACKS = new EnumMap<>(class_3264.class);

    public static void registerPack(Consumer<ResourcePackManager.Event> listener) {
        listener.accept((packType, pack) -> {
            if (pack == null) return;
            PACKS.computeIfAbsent(packType, p -> new ArrayList<>()).add(pack);

            // Update client resource repository immediately if applicable
            if (Environment.isClientSide() && packType == class_3264.field_14188) {
                updateClientRepository();
            }
        });
    }

    private static void updateClientRepository() {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.method_1520() instanceof PackRepositoryAccessor repository) {
            Set<class_3285> sources = new HashSet<>(repository.getSources());
            getAdditionalPacks(class_3264.field_14188)
                .forEach(pack -> sources.add(onLoad -> onLoad.accept(pack.get())));
            repository.setSources(sources);
        }
    }

    public static Collection<Supplier<class_3288>> getAdditionalPacks(@Nullable class_3264 packType) {
        List<Supplier<class_3288>> result = PACKS.get(packType);
        return result != null ? result : Collections.emptyList();
    }
}