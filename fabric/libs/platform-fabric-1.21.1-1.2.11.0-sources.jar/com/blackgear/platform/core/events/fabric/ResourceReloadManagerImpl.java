package com.blackgear.platform.core.events.fabric;

import com.blackgear.platform.core.events.ResourceReloadManager;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

public class ResourceReloadManagerImpl {
    public static void registerClient(Consumer<ResourceReloadManager.ListenerEvent> event) {
        event.accept((id, listener) -> ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(listenerWrapper(id, listener)));
    }

    public static void registerServer(Consumer<ResourceReloadManager.ListenerEvent> event) {
        event.accept((id, listener) -> ResourceManagerHelper.get(class_3264.field_14190).registerReloadListener(listenerWrapper(id, listener)));
    }

    private static IdentifiableResourceReloadListener listenerWrapper(class_2960 id, class_3302 listener) {
        return new IdentifiableResourceReloadListener() {
            @Override
            public class_2960 getFabricId() {
                return id;
            }

            @Override
            public @NotNull CompletableFuture<Void> method_25931(class_4045 preparationBarrier, class_3300 resourceManager, class_3695 preparationsProfiler, class_3695 reloadProfiler, Executor backgroundExecutor, Executor gameExecutor) {
                return listener.method_25931(preparationBarrier, resourceManager, preparationsProfiler, reloadProfiler, backgroundExecutor, gameExecutor);
            }
        };
    }
}