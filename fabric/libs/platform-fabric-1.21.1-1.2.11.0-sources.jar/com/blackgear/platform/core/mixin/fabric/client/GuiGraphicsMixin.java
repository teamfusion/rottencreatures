package com.blackgear.platform.core.mixin.fabric.client;

import com.blackgear.platform.client.event.screen.TooltipEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

@Mixin(class_332.class)
public class GuiGraphicsMixin {
    @Inject(method = "renderTooltipInternal", at = @At("HEAD"), cancellable = true)
    private void platform$onRenderTooltipInternal(class_327 font, List<class_5684> components, int mouseX, int mouseY, class_8000 tooltipPositioner, CallbackInfo ci) {
        if (!components.isEmpty()) {
            if (TooltipEvents.RENDER_TOOLTIP.invoker().onRendering((class_332) (Object) this, components, mouseX, mouseY).isCancelled()) {
                ci.cancel();
            }
        }
    }
}