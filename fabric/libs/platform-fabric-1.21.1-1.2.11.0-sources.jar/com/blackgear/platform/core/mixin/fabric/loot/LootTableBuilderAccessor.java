package com.blackgear.platform.core.mixin.fabric.loot;

import com.google.common.collect.ImmutableList;
import net.minecraft.class_52;
import net.minecraft.class_55;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_52.class_53.class)
public interface LootTableBuilderAccessor {
    @Accessor ImmutableList.Builder<class_55> getPools();

    @Accessor("pools")
    void setPools(ImmutableList.Builder<class_55> pools);
}