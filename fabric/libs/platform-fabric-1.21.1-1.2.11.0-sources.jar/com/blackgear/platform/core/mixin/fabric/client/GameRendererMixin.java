package com.blackgear.platform.core.mixin.fabric.client;

import com.blackgear.platform.client.event.screen.HudRendering;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(value = class_757.class, priority = 1100)
public class GameRendererMixin {
    @Shadow @Final class_310 minecraft;

    @Inject(
        method = "render",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screens/Screen;renderWithTooltip(Lnet/minecraft/client/gui/GuiGraphics;IIF)V",
            ordinal = 0
        ),
        locals = LocalCapture.CAPTURE_FAILHARD,
        cancellable = true
    )
    public void renderScreenPre(class_9779 tickDelta, boolean renderLevel, CallbackInfo ci, boolean gameLoaded, int mouseX, int mouseY, class_1041 window, Matrix4f matrix, Matrix4fStack matrices, class_332 graphics) {
        if (HudRendering.PRE_RENDERING.invoker().onRender(this.minecraft, this.minecraft.field_1755, graphics, mouseX, mouseY, tickDelta).isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(
        method = "render",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screens/Screen;renderWithTooltip(Lnet/minecraft/client/gui/GuiGraphics;IIF)V",
            shift = At.Shift.AFTER,
            ordinal = 0
        ),
        locals = LocalCapture.CAPTURE_FAILHARD
    )
    public void renderScreenPost(class_9779 tickDelta, boolean renderLevel, CallbackInfo ci, boolean gameLoaded, int mouseX, int mouseY, class_1041 window, Matrix4f matrix, Matrix4fStack matrices, class_332 graphics) {
        HudRendering.POST_RENDERING.invoker().onRender(this.minecraft, this.minecraft.field_1755, graphics, mouseX, mouseY, tickDelta);
    }
}