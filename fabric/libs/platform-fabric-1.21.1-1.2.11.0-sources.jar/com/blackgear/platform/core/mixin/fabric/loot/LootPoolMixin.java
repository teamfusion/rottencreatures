package com.blackgear.platform.core.mixin.fabric.loot;

import com.blackgear.platform.Platform;

import com.blackgear.platform.common.data.fabric.LootPoolAccess;
import com.google.common.collect.Lists;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_117;
import net.minecraft.class_5341;
import net.minecraft.class_55;
import net.minecraft.class_5658;
import net.minecraft.class_79;

@Mixin(class_55.class)
public class LootPoolMixin implements LootPoolAccess {
    @Shadow @Final public class_5658 rolls;
    @Shadow @Final public class_5658 bonusRolls;
    @Shadow @Final public List<class_5341> conditions;
    @Shadow @Final public List<class_117> functions;
    @Shadow @Final public List<class_79> entries;

    @Invoker("<init>")
    static class_55 create(List<class_79> entries, List<class_5341> conditions, List<class_117> functions, class_5658 rolls, class_5658 bonusRolls) {
        throw new AssertionError();
    }

    @Override
    public class_55 mergeEntries(List<class_79> contents) {
        final List<class_79> merged = Lists.newArrayList(entries);
        merged.addAll(contents);

        return create(
            merged,
            this.conditions,
            this.functions,
            this.rolls,
            this.bonusRolls
        );
    }
}