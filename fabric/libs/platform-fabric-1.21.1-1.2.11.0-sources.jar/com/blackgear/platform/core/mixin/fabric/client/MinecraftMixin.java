package com.blackgear.platform.core.mixin.fabric.client;

import com.blackgear.platform.client.event.LocalPlayerEvents;
import com.blackgear.platform.client.event.screen.HudRendering;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Shadow @Nullable public class_746 player;

    @Inject(
        method = "clearClientLevel",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/GameNarrator;clear()V"
        )
    )
    private void platform$onLogout(class_437 screen, CallbackInfo ci) {
        LocalPlayerEvents.ON_LOGOUT.invoker().onLogout(this.player);
    }

    @Inject(
        method = "setScreen",
        at = @At(
            value = "FIELD",
            target = "Lnet/minecraft/client/Minecraft;screen:Lnet/minecraft/client/gui/screens/Screen;",
            opcode = Opcodes.PUTFIELD
        )
    )
    private void platform$onScreenOpen(class_437 screen, CallbackInfo ci) {
        HudRendering.OPEN_CONTAINER.invoker().onOpen((class_310)(Object)this, screen);
    }

    @Inject(
        method = "setScreen",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screens/Screen;removed()V"
        )
    )
    private void platform$onScreenClose(class_437 screen, CallbackInfo ci) {
        class_310 minecraft = (class_310)(Object)this;
        HudRendering.CLOSE_CONTAINER.invoker().onClose(minecraft, minecraft.field_1755);
    }
}