package com.blackgear.platform.core.mixin.fabric;

import com.blackgear.platform.common.events.EntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = {
    class_1309.class,
    class_1657.class,
    class_3222.class
})
public class LivingDeathMixin {
    @Inject(
        method = "die",
        at = @At("HEAD"),
        cancellable = true
    )
    private void platform$onDeath(class_1282 source, CallbackInfo ci) {
        if (EntityEvents.ON_DEATH.invoker().onDeath((class_1309) (Object) this, source).isCancelled()) {
            ci.cancel();
        }
    }
}