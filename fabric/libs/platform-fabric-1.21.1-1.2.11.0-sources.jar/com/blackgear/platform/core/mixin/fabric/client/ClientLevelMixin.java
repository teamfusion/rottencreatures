package com.blackgear.platform.core.mixin.fabric.client;

import com.blackgear.platform.common.events.EntityEvents;
import net.minecraft.class_1297;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public class ClientLevelMixin {
    @Inject(
        method = "addEntity",
        at = @At("HEAD"),
        cancellable = true
    )
    private void platform$addEntity(class_1297 entity, CallbackInfo ci) {
        if (EntityEvents.ON_SPAWN.invoker().onSpawn(entity, (class_638) (Object) this).isCancelled()) {
            ci.cancel();
        }
    }
}