package com.blackgear.platform.core.mixin.fabric;

import com.blackgear.platform.common.events.EntityEvents;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3218.class)
public abstract class ServerLevelMixin {
    @Inject(
        method = "addPlayer",
        at = @At("HEAD"),
        cancellable = true
    )
    private void platform$addPlayer(class_3222 player, CallbackInfo ci) {
        if (EntityEvents.ON_SPAWN.invoker().onSpawn(player, (class_3218) (Object) this).isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(
        method = "addEntity",
        at = @At("HEAD"),
        cancellable = true
    )
    private void platform$addEntity(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
        if (EntityEvents.ON_SPAWN.invoker().onSpawn(entity, (class_3218) (Object) this).isCancelled()) {
            cir.setReturnValue(false);
        }
    }
}