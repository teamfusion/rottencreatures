package com.blackgear.platform.core.mixin.fabric.client;

import com.blackgear.platform.common.events.EntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import net.minecraft.class_745;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = {
    class_746.class,
    class_745.class
})
public class ClientPlayerAttackMixin {
    @Inject(
        method = "hurt",
        at = @At("HEAD"),
        cancellable = true
    )
    private void platform$onAttack(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (EntityEvents.ON_ATTACK.invoker().onAttack((class_1657) (Object) this, source).isCancelled()) {
            cir.setReturnValue(false);
        }
    }
}