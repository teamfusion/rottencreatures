package com.blackgear.platform.core.mixin.fabric;

import com.blackgear.platform.common.events.EntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public class PlayerAttackMixin {
    @Inject(
        method = "hurt",
        at = @At("HEAD"),
        cancellable = true
    )
    private void platform$onAttack(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (EntityEvents.ON_ATTACK.invoker().onAttack((class_1657) (Object) this, source).isCancelled()) {
            cir.setReturnValue(false);
        }
    }
}