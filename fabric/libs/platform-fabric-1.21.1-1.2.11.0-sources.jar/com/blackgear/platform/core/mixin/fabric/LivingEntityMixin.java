package com.blackgear.platform.core.mixin.fabric;

import com.blackgear.platform.common.events.EntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public class LivingEntityMixin {
    @Inject(
        method = "hurt",
        at = @At("HEAD"),
        cancellable = true
    )
    private void platform$onAttack(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof class_1657) return;

        if (EntityEvents.ON_ATTACK.invoker().onAttack((class_1309) (Object) this, source).isCancelled()) {
            cir.setReturnValue(false);
        }
    }
}