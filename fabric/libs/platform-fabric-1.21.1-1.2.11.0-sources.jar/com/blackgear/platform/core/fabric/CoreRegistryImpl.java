package com.blackgear.platform.core.fabric;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.platform.core.RegistryHolder;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class CoreRegistryImpl<T> extends CoreRegistry<T> {
    private final class_2378<T> registry;

    protected CoreRegistryImpl(class_2378<T> registry, String modId) {
        super(modId);
        this.registry = registry;
    }

    @SuppressWarnings("unchecked")
    public static <T> CoreRegistry<T> create(class_5321<? extends class_2378<T>> key, String modId) {
        class_2378<?> registry = class_7923.field_41167.method_10223(key.method_29177());
        if (registry == null) throw new IllegalArgumentException("Unknown registry: " + key.method_29177());

        return new CoreRegistryImpl<>((class_2378<T>) registry, modId);
    }

    public static <T> CoreRegistry<T> create(class_2378<T> registry, String modId) {
        return new CoreRegistryImpl<>(registry, modId);
    }

    @Override
    public <E extends T> Supplier<E> register(String name, Supplier<E> entry) {
        E value = class_2378.method_10230(this.registry, class_2960.method_60655(this.modId, name), entry.get());
        this.entries.add(() -> value);
        return () -> value;
    }

    @Override @SuppressWarnings("unchecked")
    public <E extends T> RegistryHolder<E> registerHolder(String name, Supplier<E> entry) {
        class_2960 value = class_2960.method_60655(this.modId, name);
        E registered = class_2378.method_10230(this.registry, value, entry.get());
        this.entries.add(() -> registered);
        return new RegistryHolder<>() {
            final class_5321<E> key = class_5321.method_29179((class_5321<? extends class_2378<E>>) registry.method_30517(), value);

            @Override
            public E get() {
                return registered;
            }

            @Override
            public Optional<class_6880<E>> getHolder() {
                class_6880<E> holder = (class_6880<E>) registry.method_40264((class_5321<T>) key).orElse(null);
                return Optional.ofNullable(holder);
            }

            @Override
            public boolean isPresent() {
                return registry.method_10250(value);
            }

            @Override
            public class_2960 getId() {
                return value;
            }

            @Override
            public class_5321<E> getKey() {
                return key;
            }
        };
    }

    @Override
    public class_5321<? extends class_2378<T>> key() {
        return this.registry.method_30517();
    }

    @Override
    public class_2378<T> registry() {
        return this.registry;
    }

    @Override
    protected void bootstrap() {
        // Nothing to do in Fabric, registration is immediate
    }
}