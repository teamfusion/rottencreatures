package com.blackgear.platform.core.fabric;

import com.blackgear.platform.core.RegistryBuilder;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import java.util.function.Supplier;

public class RegistryBuilderImpl {
    public static RegistryBuilder create(String modId) {
        return new RegistryBuilder(modId) {
            @Override
            public <T> Supplier<class_2378<T>> registry(class_5321<class_2378<T>> key) {
                class_2370<T> registry = FabricRegistryBuilder.createSimple(key).buildAndRegister();
                return () -> registry;
            }
        };
    }
}