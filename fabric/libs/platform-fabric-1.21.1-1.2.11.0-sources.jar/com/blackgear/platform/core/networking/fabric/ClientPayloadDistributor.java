package com.blackgear.platform.core.networking.fabric;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_8710;

public class ClientPayloadDistributor {
    @Environment(EnvType.CLIENT)
    public static void sendToServer(class_8710 payload) {
        ClientPlayNetworking.send(payload);
    }
}