package com.blackgear.platform.core.networking.fabric;

import com.blackgear.platform.core.Environment;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import org.jetbrains.annotations.Nullable;

public class PayloadDistributorImpl {
    public static void sendToServer(class_8710 payload) {
        if (Environment.isClientSide()) ClientPayloadDistributor.sendToServer(payload);
    }

    public static void sendToPlayer(class_3222 player, class_8710 payload) {
        ServerPlayNetworking.send(player, payload);
    }

    public static void sendToPlayersInDimension(class_3218 level, class_8710 payload) {
        PlayerLookup.world(level).forEach(player -> ServerPlayNetworking.send(player, payload));
    }

    public static void sendToPlayersNear(class_3218 level, @Nullable class_3222 excluded, double x, double y, double z, double radius, class_8710 payload) {
        PlayerLookup.around(level, new class_243(x, y, z), radius).forEach(player -> {
            if (player != excluded) {
                ServerPlayNetworking.send(player, payload);
            }
        });
    }

    public static void sendToAllPlayers(class_8710 payload) {
        Environment.getCurrentServer().ifPresent(server -> {
            PlayerLookup.all(server).forEach(player -> ServerPlayNetworking.send(player, payload));
        });
    }

    public static void sendToPlayersTrackingEntity(class_1297 entity, class_8710 payload) {
        PlayerLookup.tracking(entity).forEach(player -> ServerPlayNetworking.send(player, payload));
    }

    public static void sendToPlayersTrackingChunk(class_3218 level, class_1923 pos, class_8710 payload) {
        PlayerLookup.tracking(level, pos).forEach(player -> ServerPlayNetworking.send(player, payload));
    }
}