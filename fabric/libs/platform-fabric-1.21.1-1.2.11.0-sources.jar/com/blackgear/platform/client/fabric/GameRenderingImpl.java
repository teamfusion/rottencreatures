package com.blackgear.platform.client.fabric;

import com.blackgear.platform.Platform;
import com.blackgear.platform.client.GameRendering;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1091;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2484;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_322;
import net.minecraft.class_326;
import net.minecraft.class_3611;
import net.minecraft.class_5598;
import net.minecraft.class_5601;
import net.minecraft.class_5616;
import net.minecraft.class_630;
import net.minecraft.class_707;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class GameRenderingImpl {
    public static final Map<class_2484.class_2485, class_2960> TEXTURE_BY_SKULL = new ConcurrentHashMap<>();
    public static final Map<class_2484.class_2485, Pair<Function<class_630, class_5598>, class_5601>> MODEL_BY_SKULL = new ConcurrentHashMap<>();

    public static void registerBlockColors(Consumer<GameRendering.BlockColorEvent> listener) {
        listener.accept(new GameRendering.BlockColorEvent() {
            @Override
            public void register(class_322 color, class_2248... blocks) {
                ColorProviderRegistry.BLOCK.register(color, blocks);
            }

            @Override
            public int getColor(class_2680 state, class_1920 level, class_2338 pos, int tint) {
                class_322 colors = ColorProviderRegistry.BLOCK.get(state.method_26204());
                return colors != null ? colors.getColor(state, level, pos, tint) : -1;
            }
        });
    }

    public static void registerItemColors(Consumer<GameRendering.ItemColorEvent> listener) {
        listener.accept(new GameRendering.ItemColorEvent() {
            @Override
            public void register(class_326 color, class_1935... items) {
                ColorProviderRegistry.ITEM.register(color, items);
            }

            @Override
            public int getColor(class_1799 stack, int tint) {
                class_2680 state = ((class_1747) stack.method_7909()).method_7711().method_9564();
                return class_310.method_1551().method_1505().method_1697(state, null, null, tint);
            }
        });
    }

    public static void registerBlockRenderers(Consumer<GameRendering.BlockRendererEvent> listener) {
        listener.accept(new GameRendering.BlockRendererEvent() {
            @Override
            public void register(class_1921 type, class_2248... blocks) {
                BlockRenderLayerMap.INSTANCE.putBlocks(type, blocks);
            }

            @Override
            public void register(class_1921 type, class_3611... fluids) {
                BlockRenderLayerMap.INSTANCE.putFluids(type, fluids);
            }
        });
    }

    public static void registerBlockEntityRenderers(Consumer<GameRendering.BlockEntityRendererEvent> listener) {
        listener.accept(class_5616::method_32144);
    }

    public static void registerEntityRenderers(Consumer<GameRendering.EntityRendererEvent> listener) {
        listener.accept(EntityRendererRegistry::register);
    }

    public static void registerModelLayers(Consumer<GameRendering.ModelLayerEvent> listener) {
        listener.accept((layer, definition) -> EntityModelLayerRegistry.registerModelLayer(layer, definition::get));
    }

    public static void registerSpecialModels(Consumer<GameRendering.SpecialModelEvent> listener) {
        GameRendering.SpecialModelEvent event = new GameRendering.SpecialModelEvent() {
            @Override
            public void register(class_2960 model) {
                ModelLoadingPlugin.register(context -> context.addModels(model));
            }

            @Override
            public void register(class_2960... models) {
                for (class_2960 model : models) this.register(model);
            }
        };
        listener.accept(event);
    }

    public static void registerModelOverrides(Consumer<GameRendering.ModelOverrideEvent> listener) {
        ModelLoadingPlugin.register(plugin -> {
            listener.accept(new GameRendering.ModelOverrideEvent() {
                @Override
                public void register(class_2960 original, class_2960 override, boolean condition) {
                    GameRendering.ModelOverrideEvent.super.register(original, override, condition);
                    plugin.addModels(class_2960.method_60655(override.method_12836(), "item/" + override.method_12832()));
                }
            });

            plugin.modifyModelAfterBake().register((model, context) -> {
                class_1091 toLevel = context.topLevelId();

                if (toLevel != null && "inventory".equals(toLevel.method_4740())) {
                    class_2960 original = toLevel.comp_2875();
                    class_2960 override = GameRendering.MODEL_OVERRIDES.get(original);

                    if (override != null) {
                        try {
                            class_2960 overrideModel = class_2960.method_60655(override.method_12836(), "item/" + override.method_12832());
                            return context.baker().method_45873(overrideModel, context.settings());
                        } catch (Exception e) {
                            Platform.LOGGER.error("Failed to load override model: {}", override);
                        }
                    }
                }

                return model;
            });
        });
    }

    public static void registerSkullRenderers(Consumer<GameRendering.SkullRendererEvent> listener) {
        GameRendering.SkullRendererEvent event = new GameRendering.SkullRendererEvent() {
            @Override
            public void registerSkullModel(class_2484.class_2485 type, Function<class_630, class_5598> model, class_5601 layer) {
                MODEL_BY_SKULL.put(type, new Pair<>(model, layer));
            }

            @Override
            public void registerSkullTexture(class_2484.class_2485 type, class_2960 texture) {
                TEXTURE_BY_SKULL.put(type, texture);
            }
        };
        listener.accept(event);
    }

    public static void registerParticleFactories(Consumer<GameRendering.ParticleFactoryEvent> listener) {
        GameRendering.ParticleFactoryEvent event = new GameRendering.ParticleFactoryEvent() {
            @Override
            public <T extends class_2394, P extends class_2396<T>> void register(Supplier<P> type, class_707<T> provider) {
                ParticleFactoryRegistry.getInstance().register(type.get(), provider);
            }

            @Override
            public <T extends class_2394, P extends class_2396<T>> void register(Supplier<P> type, Factory<T> factory) {
                ParticleFactoryRegistry.getInstance().register(type.get(), factory::create);
            }
        };
        listener.accept(event);
    }
}