package com.blackgear.platform.client.v2.emissive.fabric;

import com.blackgear.platform.client.v2.emissive.Emissiveness;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

public class FabricEmissiveLayerBakedModel extends ForwardingBakedModel {
    private static RenderMaterial[] emissiveMaterials;
    private static final ConcurrentHashMap<class_2680, Boolean> SOLID_RENDER_TYPE_CACHE = new ConcurrentHashMap<>();

    public FabricEmissiveLayerBakedModel(class_1087 wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
        this.processBlockQuads(context, () -> super.emitBlockQuads(blockView, state, pos, randomSupplier, context), state);
    }

    @Override
    public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
        this.processItemQuads(context, () -> super.emitItemQuads(stack, randomSupplier, context));
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    private static RenderMaterial[] getEmissiveMaterials() {
        if (emissiveMaterials == null) emissiveMaterials = createEmissiveMaterials();
        return emissiveMaterials;
    }

    private static RenderMaterial[] createEmissiveMaterials() {
        RenderMaterial[] materials = new RenderMaterial[BlendMode.values().length];
        MaterialFinder finder = RendererAccess.INSTANCE.getRenderer().materialFinder();

        for (BlendMode mode : BlendMode.values()) {
            materials[mode.ordinal()] = finder.emissive(true).disableDiffuse(true).ambientOcclusion(TriState.FALSE).blendMode(mode).find();
        }

        return materials;
    }

    private static boolean isDefaultLayerSolid(class_2680 state) {
        Boolean cached = SOLID_RENDER_TYPE_CACHE.get(state);
        if (cached == null) {
            cached = class_4696.method_23679(state) == class_1921.method_23577();
            SOLID_RENDER_TYPE_CACHE.put(state, cached);
        }

        return cached;
    }

    private void processBlockQuads(RenderContext context, Runnable originalEmitter, class_2680 state) {
        MeshBuilder meshBuilder = RendererAccess.INSTANCE.getRenderer().meshBuilder();
        EmissiveBlockQuadTransform transformer = new EmissiveBlockQuadTransform(meshBuilder.getEmitter(), state, context);

        context.pushTransform(transformer);
        try {
            originalEmitter.run();
        } finally {
            context.popTransform();
        }

        if (transformer.didEmit()) {
            meshBuilder.build().outputTo(context.getEmitter());
        }
    }

    private void processItemQuads(RenderContext context, Runnable originalEmitter) {
        MeshBuilder meshBuilder = RendererAccess.INSTANCE.getRenderer().meshBuilder();
        EmissiveItemQuadTransform transformer = new EmissiveItemQuadTransform(meshBuilder.getEmitter());

        context.pushTransform(transformer);
        try {
            originalEmitter.run();
        } finally {
            context.popTransform();
        }

        if (transformer.didEmit()) {
            meshBuilder.build().outputTo(context.getEmitter());
        }
    }

    private static void interpolateUV(MutableQuadView quad, class_1058 from, class_1058 to) {
        float fromU = from.method_4594();
        float fromV = from.method_4593();
        float toU = to.method_4594();
        float toV = to.method_4593();
        float scaleU = (to.method_4577() - toU) / (from.method_4577() - fromU);
        float scaleV = (to.method_4575() - toV) / (from.method_4575() - fromV);

        quad.uv(0, toU + (quad.u(0) - fromU) * scaleU, toV + (quad.v(0) - fromV) * scaleV);
        quad.uv(1, toU + (quad.u(1) - fromU) * scaleU, toV + (quad.v(1) - fromV) * scaleV);
        quad.uv(2, toU + (quad.u(2) - fromU) * scaleU, toV + (quad.v(2) - fromV) * scaleV);
        quad.uv(3, toU + (quad.u(3) - fromU) * scaleU, toV + (quad.v(3) - fromV) * scaleV);
    }

    private abstract static class EmissiveQuadTransform implements RenderContext.QuadTransform {
        protected final QuadEmitter emitter;
        private int emittedCount = 0;

        protected EmissiveQuadTransform(QuadEmitter emitter) {
            this.emitter = emitter;
        }

        public final boolean didEmit() {
            return this.emittedCount > 0;
        }

        protected final void emitEmissiveQuad(MutableQuadView quad, class_1058 originalSprite, class_1058 emissiveSprite, RenderMaterial material) {
            this.emitter.copyFrom(quad);
            this.emitter.material(material);
            interpolateUV(emitter, originalSprite, emissiveSprite);
            this.emitter.emit();
            this.emittedCount++;
        }

        protected final void tryEmitEmissiveQuad(MutableQuadView quad, RenderMaterial material) {
            class_1058 originalSprite = BlockSpriteListener.getSprites().find(quad);
            if (originalSprite == null) return;

            class_1058 emissiveSprite = Emissiveness.INSTANCE.getEmissiveSprite(originalSprite);
            if (emissiveSprite != null) {
                emitEmissiveQuad(quad, originalSprite, emissiveSprite, material);
            }
        }
    }

    private static final class EmissiveBlockQuadTransform extends EmissiveQuadTransform {
        private final RenderContext renderContext;
        private final RenderMaterial[] materials;
        private final boolean isDefaultLayerSolid;

        private EmissiveBlockQuadTransform(QuadEmitter emitter, class_2680 state, RenderContext renderContext) {
            super(emitter);
            this.renderContext = renderContext;
            this.materials = getEmissiveMaterials();
            this.isDefaultLayerSolid = isDefaultLayerSolid(state);
        }

        @Override
        public boolean transform(MutableQuadView quad) {
            if (this.renderContext.isFaceCulled(quad.cullFace())) return false;

            this.tryEmitEmissiveQuad(quad, getEmissiveMaterial(quad.material().blendMode()));
            return true;
        }

        private RenderMaterial getEmissiveMaterial(BlendMode mode) {
            if (mode == BlendMode.DEFAULT) {
                return this.isDefaultLayerSolid
                    ? this.materials[BlendMode.CUTOUT_MIPPED.ordinal()]
                    : this.materials[BlendMode.DEFAULT.ordinal()];
            }

            if (mode == BlendMode.SOLID) {
                return this.materials[BlendMode.CUTOUT_MIPPED.ordinal()];
            }

            return this.materials[mode.ordinal()];
        }
    }

    private static final class EmissiveItemQuadTransform extends EmissiveQuadTransform {
        private final RenderMaterial material;

        private EmissiveItemQuadTransform(QuadEmitter emitter) {
            super(emitter);
            this.material = getEmissiveMaterials()[BlendMode.DEFAULT.ordinal()];
        }

        @Override
        public boolean transform(MutableQuadView quad) {
            this.tryEmitEmissiveQuad(quad, this.material);
            return true;
        }
    }
}