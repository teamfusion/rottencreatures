package com.blackgear.platform.client.v2.emissive.fabric;

import com.blackgear.platform.client.v2.emissive.EmissiveModelWrapper;
import com.blackgear.platform.client.v2.emissive.EmissiveModelWrapperHolder;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.minecraft.class_1087;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public class EmissiveModelWrapperImpl {
    public static void bootstrap() {
        ModelLoadingPlugin.register(context -> {
            context.modifyModelAfterBake().register(ModelModifier.WRAP_LAST_PHASE, (model, ctx) -> {
                class_2960 resource = ctx.resourceId();
                if (resource != null && !"minecraft".equals(resource.method_12836())) return model;

                @Nullable EmissiveModelWrapper wrapper = ((EmissiveModelWrapperHolder) ctx.loader()).getModelWrapper();
                return wrapper != null ? wrapper.wrap(model, resource) : model;
            });
        });
    }

    public static class_1087 getBakedModel(class_1087 model) {
        return new FabricEmissiveLayerBakedModel(model);
    }
}