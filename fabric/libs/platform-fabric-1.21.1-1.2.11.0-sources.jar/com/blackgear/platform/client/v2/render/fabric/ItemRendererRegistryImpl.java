package com.blackgear.platform.client.v2.render.fabric;

import com.blackgear.platform.client.v2.render.ItemRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1935;

public class ItemRendererRegistryImpl {
    public static void registerRenderer(class_1935 item, ItemRendererRegistry.DynamicItemRenderer renderer) {
        BuiltinItemRendererRegistry.INSTANCE.register(item.method_8389(), renderer::render);
    }
}