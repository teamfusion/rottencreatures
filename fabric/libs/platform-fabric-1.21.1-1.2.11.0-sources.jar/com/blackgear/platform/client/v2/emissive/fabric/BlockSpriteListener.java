package com.blackgear.platform.client.v2.emissive.fabric;

import com.blackgear.platform.Platform;
import net.fabricmc.fabric.api.renderer.v1.model.SpriteFinder;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourceReloadListenerKeys;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1059;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import java.util.Collection;
import java.util.List;

public class BlockSpriteListener implements SimpleSynchronousResourceReloadListener {
    public static final class_2960 ID = Platform.resource("block_sprite");
    private static final BlockSpriteListener INSTANCE = new BlockSpriteListener();
    private static SpriteFinder sprites;

    public static void init() {
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(INSTANCE);
    }

    @Override
    public void method_14491(class_3300 manager) {
        class_1092 models = class_310.method_1551().method_1554();
        sprites = SpriteFinder.get(models.method_24153(class_1059.field_5275));
    }

    @Override
    public class_2960 getFabricId() {
        return ID;
    }

    @Override
    public Collection<class_2960> getFabricDependencies() {
        return List.of(ResourceReloadListenerKeys.MODELS);
    }

    public static SpriteFinder getSprites() {
        return sprites;
    }
}